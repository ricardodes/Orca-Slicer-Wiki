'use client'

import { useState } from 'react'
import { jsPDF } from 'jspdf'
import { Check, Copy, Download, FileText, ImageIcon } from 'lucide-react'

type Item = {
  moduloNumero: number
  moduloTitulo: string
  moduloSlug: string
  licaoTitulo: string
  arquivo: string
  prompt: string
}

export function ImagensAdminView({ itens }: { itens: Item[] }) {
  const [copiado, setCopiado] = useState<string | null>(null)

  const totalModulos = new Set(itens.map((i) => i.moduloSlug)).size

  async function copiar(arquivo: string, prompt: string) {
    try {
      await navigator.clipboard.writeText(prompt)
      setCopiado(arquivo)
      setTimeout(() => setCopiado(null), 1500)
    } catch {
      // ignore
    }
  }

  function baixarPdf() {
    const doc = new jsPDF({ unit: 'pt', format: 'a4' })
    const margin = 40
    const largura = doc.internal.pageSize.getWidth() - margin * 2
    let y = margin

    const novaPaginaSeNecessario = (altura: number) => {
      if (y + altura > doc.internal.pageSize.getHeight() - margin) {
        doc.addPage()
        y = margin
      }
    }

    doc.setFont('helvetica', 'bold')
    doc.setFontSize(18)
    doc.text('Prompts de imagens — Curso OrcaSlicer', margin, y)
    y += 22
    doc.setFont('helvetica', 'normal')
    doc.setFontSize(10)
    doc.setTextColor(110)
    doc.text(
      'Gere cada imagem na sua IA, salve em public/imagens-licoes/ com o nome do arquivo indicado.',
      margin,
      y,
    )
    y += 26
    doc.setTextColor(0)

    let moduloAtual = -1
    itens.forEach((item, idx) => {
      if (item.moduloNumero !== moduloAtual) {
        moduloAtual = item.moduloNumero
        novaPaginaSeNecessario(40)
        y += 8
        doc.setFont('helvetica', 'bold')
        doc.setFontSize(13)
        doc.setTextColor(220, 90, 30)
        doc.text(
          `Módulo ${String(item.moduloNumero).padStart(2, '0')} — ${item.moduloTitulo}`,
          margin,
          y,
        )
        doc.setTextColor(0)
        y += 18
      }

      doc.setFont('helvetica', 'bold')
      doc.setFontSize(11)
      const titulo = doc.splitTextToSize(
        `${idx + 1}. ${item.licaoTitulo}`,
        largura,
      )
      novaPaginaSeNecessario(titulo.length * 14 + 10)
      doc.text(titulo, margin, y)
      y += titulo.length * 14 + 2

      doc.setFont('courier', 'normal')
      doc.setFontSize(9)
      doc.setTextColor(120)
      doc.text(`Arquivo: ${item.arquivo}`, margin, y)
      y += 14
      doc.setTextColor(0)

      doc.setFont('helvetica', 'normal')
      doc.setFontSize(10)
      const prompt = doc.splitTextToSize(item.prompt, largura)
      novaPaginaSeNecessario(prompt.length * 13 + 16)
      doc.text(prompt, margin, y)
      y += prompt.length * 13 + 18
    })

    doc.save('prompts-imagens-orcaslicer.pdf')
  }

  let moduloRender = -1

  return (
    <main className="mx-auto max-w-3xl px-5 py-10 md:px-8">
      <header className="mb-8">
        <div className="flex items-center gap-2 text-primary">
          <ImageIcon className="h-5 w-5" />
          <span className="text-xs font-semibold uppercase tracking-wide">
            Área privada
          </span>
        </div>
        <h1 className="mt-2 text-balance text-3xl font-bold tracking-tight text-foreground">
          Prompts e arquivos de imagem
        </h1>
        <p className="mt-3 text-pretty leading-relaxed text-muted-foreground">
          {itens.length} imagens em {totalModulos} módulos. Gere cada imagem na
          IA que preferir usando o prompt, depois salve o arquivo em{' '}
          <code className="rounded bg-muted px-1.5 py-0.5 font-mono text-sm text-foreground">
            public/imagens-licoes/
          </code>{' '}
          com o nome exato indicado. A imagem aparece sozinha no topo da lição.
        </p>

        <button
          onClick={baixarPdf}
          className="mt-5 inline-flex items-center gap-2 rounded-lg bg-primary px-5 py-2.5 font-medium text-primary-foreground transition-colors hover:bg-primary/90"
        >
          <Download className="h-4 w-4" />
          Baixar PDF com todos os prompts
        </button>
      </header>

      <div className="space-y-3">
        {itens.map((item, idx) => {
          const novoModulo = item.moduloNumero !== moduloRender
          moduloRender = item.moduloNumero
          return (
            <div key={item.arquivo}>
              {novoModulo && (
                <div className="mb-3 mt-8 flex items-center gap-2 border-b border-border pb-2 first:mt-0">
                  <FileText className="h-4 w-4 text-primary" />
                  <h2 className="text-sm font-semibold uppercase tracking-wide text-foreground">
                    Módulo {String(item.moduloNumero).padStart(2, '0')} —{' '}
                    {item.moduloTitulo}
                  </h2>
                </div>
              )}
              <div className="rounded-xl border border-border bg-card p-4">
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <p className="font-medium text-foreground">
                      {idx + 1}. {item.licaoTitulo}
                    </p>
                    <p className="mt-1 break-all font-mono text-xs text-primary">
                      {item.arquivo}
                    </p>
                  </div>
                  <button
                    onClick={() => copiar(item.arquivo, item.prompt)}
                    className="inline-flex shrink-0 items-center gap-1.5 rounded-md border border-border bg-background px-3 py-1.5 text-xs font-medium text-foreground transition-colors hover:border-primary/40"
                  >
                    {copiado === item.arquivo ? (
                      <>
                        <Check className="h-3.5 w-3.5 text-chart-2" />
                        Copiado
                      </>
                    ) : (
                      <>
                        <Copy className="h-3.5 w-3.5" />
                        Copiar prompt
                      </>
                    )}
                  </button>
                </div>
                <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
                  {item.prompt}
                </p>
              </div>
            </div>
          )
        })}
      </div>
    </main>
  )
}
