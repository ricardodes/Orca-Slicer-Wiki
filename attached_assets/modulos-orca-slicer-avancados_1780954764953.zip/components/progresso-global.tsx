'use client'

import { Trophy, RotateCcw } from 'lucide-react'
import { Progress } from '@/components/ui/progress'
import { useProgresso } from '@/hooks/use-progresso'
import { totalLicoes } from '@/lib/course'

export function ProgressoGlobal() {
  const { totalConcluidas, carregado, resetar } = useProgresso()
  const pct = carregado
    ? Math.round((totalConcluidas / totalLicoes) * 100)
    : 0

  return (
    <div>
      <div className="mb-2 flex items-center justify-between">
        <div className="flex items-center gap-1.5">
          <Trophy className="h-4 w-4 text-primary" />
          <span className="text-xs font-medium text-foreground">
            Seu progresso
          </span>
        </div>
        <span className="font-mono text-xs font-bold text-primary">{pct}%</span>
      </div>
      <Progress value={pct} className="h-2" />
      <div className="mt-2 flex items-center justify-between">
        <span className="text-[11px] text-muted-foreground">
          {carregado ? totalConcluidas : 0} de {totalLicoes} lições
        </span>
        {carregado && totalConcluidas > 0 && (
          <button
            onClick={resetar}
            className="flex items-center gap-1 text-[11px] text-muted-foreground transition-colors hover:text-foreground"
          >
            <RotateCcw className="h-3 w-3" />
            Zerar
          </button>
        )}
      </div>
    </div>
  )
}
