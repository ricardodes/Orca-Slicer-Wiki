'use client'

import { useState } from 'react'
import Link from 'next/link'
import {
  AlertTriangle,
  ArrowLeft,
  ArrowRight,
  CheckCircle2,
  Circle,
  Clock,
  Flame,
  Gauge,
  HelpCircle,
  Lightbulb,
  ListChecks,
  Settings2,
  ShieldCheck,
  Target,
  Trophy,
  Wrench,
  XCircle,
} from 'lucide-react'
import { cn } from '@/lib/utils'
import type { Licao } from '@/lib/types'
import type { FlatLicao } from '@/lib/course'
import { useProgresso } from '@/hooks/use-progresso'
import { Badge } from '@/components/ui/badge'
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion'

const NIVEL_VARIANT: Record<string, string> = {
  Iniciante: 'bg-chart-2/15 text-chart-2 border-chart-2/30',
  Intermediário: 'bg-chart-1/15 text-chart-1 border-chart-1/30',
  Avançado: 'bg-primary/15 text-primary border-primary/30',
  Especialista: 'bg-destructive/15 text-destructive border-destructive/30',
}

export function LessonView({
  moduloSlug,
  moduloNumero,
  moduloTitulo,
  licao,
  nav,
}: {
  moduloSlug: string
  moduloNumero: number
  moduloTitulo: string
  licao: Licao
  nav: {
    anterior?: FlatLicao
    proxima?: FlatLicao
    atual: number
    total: number
  }
}) {
  const id = `${moduloSlug}/${licao.slug}`
  const { estaConcluida, alternar, carregado } = useProgresso()
  const feita = carregado && estaConcluida(id)

  return (
    <article className="mx-auto max-w-3xl px-5 py-8 md:px-8 md:py-12">
      {/* Breadcrumb */}
      <div className="flex items-center gap-2 text-sm text-muted-foreground">
        <Link href="/" className="transition-colors hover:text-foreground">
          Início
        </Link>
        <span>/</span>
        <span className="font-mono text-xs">
          Módulo {`0${moduloNumero}`.slice(-2)}
        </span>
      </div>

      {/* Cabeçalho */}
      <header className="mt-4">
        <div className="flex flex-wrap items-center gap-2">
          <Badge
            variant="outline"
            className={cn('border', NIVEL_VARIANT[licao.nivel])}
          >
            {licao.nivel}
          </Badge>
          <span className="flex items-center gap-1 text-xs text-muted-foreground">
            <Clock className="h-3.5 w-3.5" />
            {licao.duracao}
          </span>
          <span className="text-xs text-muted-foreground">
            Lição {nav.atual + 1} de {nav.total}
          </span>
        </div>

        <h1 className="mt-3 text-balance text-3xl font-bold leading-tight tracking-tight text-foreground md:text-4xl">
          {licao.titulo}
        </h1>
        <p className="mt-3 text-pretty text-lg leading-relaxed text-muted-foreground">
          {licao.resumo}
        </p>
      </header>

      {/* Imagem da lição (aparece só quando o arquivo existir em public/imagens-licoes/) */}
      <LicaoImagem
        src={`/imagens-licoes/${moduloSlug}__${licao.slug}.jpg`}
        alt={licao.titulo}
      />

      {/* Intro */}
      <div className="mt-8 space-y-4">
        {licao.intro.map((p, i) => (
          <p key={i} className="leading-relaxed text-foreground/90">
            {p}
          </p>
        ))}
      </div>

      {/* Seções */}
      {licao.secoes.map((sec, i) => (
        <section key={i} className="mt-8">
          <h2 className="text-pretty text-xl font-semibold tracking-tight text-foreground">
            {sec.titulo}
          </h2>
          <div className="mt-3 space-y-3">
            {sec.conteudo.map((c, j) => (
              <Paragrafo key={j} texto={c} />
            ))}
          </div>
        </section>
      ))}

      {/* Tabelas */}
      {licao.tabelas?.map((tab, i) => (
        <section key={i} className="mt-8">
          <h3 className="mb-3 text-pretty text-lg font-semibold text-foreground">
            {tab.titulo}
          </h3>
          <div className="overflow-x-auto rounded-lg border border-border">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border bg-muted/50">
                  {tab.colunas.map((col, j) => (
                    <th
                      key={j}
                      className="px-4 py-2.5 text-left font-semibold text-foreground"
                    >
                      {col}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {tab.linhas.map((linha, j) => (
                  <tr
                    key={j}
                    className="border-b border-border last:border-0 even:bg-muted/20"
                  >
                    {linha.map((cel, k) => (
                      <td
                        key={k}
                        className={cn(
                          'px-4 py-2.5 align-top text-foreground/90',
                          k === 0 && 'font-medium text-foreground',
                        )}
                      >
                        {cel}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      ))}

      {/* Estrutura técnica */}
      {licao.estrutura && <EstruturaTecnicaView est={licao.estrutura} />}

      {/* Exercícios / Testes */}
      {(licao.exercicios?.length || licao.testes?.length) && (
        <div className="mt-8 grid gap-4 sm:grid-cols-2">
          {licao.exercicios?.length ? (
            <BlocoLista
              icon={ListChecks}
              titulo="Exercícios práticos"
              itens={licao.exercicios}
              cor="text-chart-1"
            />
          ) : null}
          {licao.testes?.length ? (
            <BlocoLista
              icon={Target}
              titulo="Testes de validação"
              itens={licao.testes}
              cor="text-chart-2"
            />
          ) : null}
        </div>
      )}

      {/* Desafio */}
      {licao.desafio && (
        <div className="mt-8 rounded-xl border border-primary/30 bg-primary/5 p-5">
          <div className="flex items-center gap-2">
            <Trophy className="h-5 w-5 text-primary" />
            <h3 className="font-semibold text-foreground">Desafio do módulo</h3>
          </div>
          <p className="mt-2 leading-relaxed text-foreground/90">
            {licao.desafio}
          </p>
        </div>
      )}

      {/* FAQ */}
      {licao.perguntas?.length ? (
        <section className="mt-8">
          <div className="mb-2 flex items-center gap-2">
            <HelpCircle className="h-5 w-5 text-muted-foreground" />
            <h3 className="text-lg font-semibold text-foreground">
              Perguntas frequentes
            </h3>
          </div>
          <Accordion className="w-full">
            {licao.perguntas.map((q, i) => (
              <AccordionItem key={i} value={`q-${i}`}>
                <AccordionTrigger className="text-left text-[15px] font-medium">
                  {q.pergunta}
                </AccordionTrigger>
                <AccordionContent className="leading-relaxed text-muted-foreground">
                  {q.resposta}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </section>
      ) : null}

      {/* Marcar concluída */}
      <div className="mt-10 flex flex-col items-center gap-3 rounded-xl border border-border bg-card p-6 text-center">
        <button
          onClick={() => alternar(id)}
          className={cn(
            'inline-flex items-center gap-2 rounded-lg px-6 py-3 font-medium transition-colors',
            feita
              ? 'bg-chart-2 text-background hover:bg-chart-2/90'
              : 'bg-primary text-primary-foreground hover:bg-primary/90',
          )}
        >
          {feita ? (
            <>
              <CheckCircle2 className="h-5 w-5" />
              Lição concluída
            </>
          ) : (
            <>
              <Circle className="h-5 w-5" />
              Marcar como concluída
            </>
          )}
        </button>
        <p className="text-sm text-muted-foreground">
          {feita
            ? 'Bom trabalho! Continue para a próxima lição.'
            : 'Marque ao terminar para acompanhar seu progresso.'}
        </p>
      </div>

      {/* Navegação */}
      <nav className="mt-8 flex flex-col gap-3 border-t border-border pt-6 sm:flex-row sm:justify-between">
        {nav.anterior ? (
          <Link
            href={`/licao/${nav.anterior.moduloSlug}/${nav.anterior.licao.slug}`}
            className="group flex flex-1 items-center gap-3 rounded-lg border border-border bg-card p-4 transition-colors hover:border-primary/40"
          >
            <ArrowLeft className="h-4 w-4 shrink-0 text-muted-foreground transition-transform group-hover:-translate-x-1" />
            <div className="min-w-0">
              <p className="text-xs text-muted-foreground">Anterior</p>
              <p className="truncate text-sm font-medium text-foreground">
                {nav.anterior.licao.titulo}
              </p>
            </div>
          </Link>
        ) : (
          <div className="flex-1" />
        )}

        {nav.proxima ? (
          <Link
            href={`/licao/${nav.proxima.moduloSlug}/${nav.proxima.licao.slug}`}
            className="group flex flex-1 items-center justify-end gap-3 rounded-lg border border-border bg-card p-4 text-right transition-colors hover:border-primary/40"
          >
            <div className="min-w-0">
              <p className="text-xs text-muted-foreground">Próxima</p>
              <p className="truncate text-sm font-medium text-foreground">
                {nav.proxima.licao.titulo}
              </p>
            </div>
            <ArrowRight className="h-4 w-4 shrink-0 text-primary transition-transform group-hover:translate-x-1" />
          </Link>
        ) : (
          <Link
            href="/"
            className="group flex flex-1 items-center justify-end gap-3 rounded-lg border border-primary/40 bg-primary/5 p-4 text-right"
          >
            <div>
              <p className="text-xs text-muted-foreground">Você chegou ao fim</p>
              <p className="text-sm font-medium text-primary">
                Voltar ao currículo
              </p>
            </div>
            <Trophy className="h-4 w-4 shrink-0 text-primary" />
          </Link>
        )}
      </nav>
    </article>
  )
}

function LicaoImagem({ src, alt }: { src: string; alt: string }) {
  const [erro, setErro] = useState(false)
  if (erro) return null
  return (
    <figure className="mt-8 overflow-hidden rounded-xl border border-border bg-card">
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img
        src={src || '/placeholder.svg'}
        alt={alt}
        onError={() => setErro(true)}
        className="aspect-video w-full object-cover"
      />
    </figure>
  )
}

function Paragrafo({ texto }: { texto: string }) {
  // Itens iniciados com "- " viram bullet destacado
  if (texto.startsWith('- ')) {
    return (
      <div className="flex gap-2.5">
        <span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-primary" />
        <p className="leading-relaxed text-foreground/90">{texto.slice(2)}</p>
      </div>
    )
  }
  return <p className="leading-relaxed text-foreground/90">{texto}</p>
}

function BlocoLista({
  icon: Icon,
  titulo,
  itens,
  cor,
}: {
  icon: React.ElementType
  titulo: string
  itens: string[]
  cor: string
}) {
  return (
    <div className="rounded-xl border border-border bg-card p-5">
      <div className="mb-3 flex items-center gap-2">
        <Icon className={cn('h-5 w-5', cor)} />
        <h3 className="font-semibold text-foreground">{titulo}</h3>
      </div>
      <ul className="space-y-2">
        {itens.map((it, i) => (
          <li key={i} className="flex gap-2.5 text-sm leading-relaxed">
            <span
              className={cn(
                'mt-0.5 font-mono text-xs font-bold',
                cor,
              )}
            >
              {`0${i + 1}`.slice(-2)}
            </span>
            <span className="text-foreground/90">{it}</span>
          </li>
        ))}
      </ul>
    </div>
  )
}

function EstruturaTecnicaView({
  est,
}: {
  est: NonNullable<Licao['estrutura']>
}) {
  const blocos: {
    cond?: string
    icon: React.ElementType
    label: string
    valor?: string
    cor: string
  }[] = [
    { icon: Settings2, label: 'O que faz', valor: est.oQueFaz, cor: 'text-foreground' },
    { icon: Gauge, label: 'Como funciona', valor: est.comoFunciona, cor: 'text-chart-1' },
    { icon: CheckCircle2, label: 'Quando usar', valor: est.quandoUsar, cor: 'text-chart-2' },
    { icon: XCircle, label: 'Quando evitar', valor: est.quandoEvitar, cor: 'text-destructive' },
    { icon: ShieldCheck, label: 'Impacto na resistência', valor: est.impactoResistencia, cor: 'text-primary' },
    { icon: Lightbulb, label: 'Impacto na qualidade', valor: est.impactoQualidade, cor: 'text-chart-1' },
    { icon: Clock, label: 'Impacto no tempo', valor: est.impactoTempo, cor: 'text-muted-foreground' },
    { icon: Flame, label: 'Impacto no filamento', valor: est.impactoFilamento, cor: 'text-chart-3' },
  ].filter((b) => b.valor)

  if (
    blocos.length === 0 &&
    !est.errosComuns?.length &&
    !est.comoCorrigir?.length &&
    !est.casosReais?.length
  ) {
    return null
  }

  return (
    <section className="mt-8 rounded-xl border border-border bg-card p-5">
      <div className="mb-4 flex items-center gap-2">
        <Wrench className="h-5 w-5 text-primary" />
        <h2 className="text-lg font-semibold text-foreground">
          Ficha técnica do parâmetro
        </h2>
      </div>

      <div className="grid gap-3 sm:grid-cols-2">
        {blocos.map((b, i) => (
          <div
            key={i}
            className="rounded-lg border border-border bg-background p-3"
          >
            <div className="flex items-center gap-1.5">
              <b.icon className={cn('h-4 w-4', b.cor)} />
              <span className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                {b.label}
              </span>
            </div>
            <p className="mt-1.5 text-sm leading-relaxed text-foreground/90">
              {b.valor}
            </p>
          </div>
        ))}
      </div>

      {est.errosComuns?.length ? (
        <div className="mt-4 rounded-lg border border-destructive/30 bg-destructive/5 p-4">
          <div className="mb-2 flex items-center gap-2">
            <AlertTriangle className="h-4 w-4 text-destructive" />
            <h4 className="text-sm font-semibold text-foreground">
              Erros comuns
            </h4>
          </div>
          <ul className="space-y-1.5">
            {est.errosComuns.map((e, i) => (
              <li key={i} className="flex gap-2 text-sm text-foreground/90">
                <span className="text-destructive">✕</span>
                {e}
              </li>
            ))}
          </ul>
        </div>
      ) : null}

      {est.comoCorrigir?.length ? (
        <div className="mt-3 rounded-lg border border-chart-2/30 bg-chart-2/5 p-4">
          <div className="mb-2 flex items-center gap-2">
            <CheckCircle2 className="h-4 w-4 text-chart-2" />
            <h4 className="text-sm font-semibold text-foreground">
              Como corrigir
            </h4>
          </div>
          <ul className="space-y-1.5">
            {est.comoCorrigir.map((e, i) => (
              <li key={i} className="flex gap-2 text-sm text-foreground/90">
                <span className="text-chart-2">→</span>
                {e}
              </li>
            ))}
          </ul>
        </div>
      ) : null}

      {est.casosReais?.length ? (
        <div className="mt-3 rounded-lg border border-border bg-background p-4">
          <div className="mb-2 flex items-center gap-2">
            <Lightbulb className="h-4 w-4 text-chart-1" />
            <h4 className="text-sm font-semibold text-foreground">
              Casos reais
            </h4>
          </div>
          <ul className="space-y-1.5">
            {est.casosReais.map((e, i) => (
              <li key={i} className="flex gap-2 text-sm text-foreground/90">
                <span className="text-chart-1">●</span>
                {e}
              </li>
            ))}
          </ul>
        </div>
      ) : null}
    </section>
  )
}
