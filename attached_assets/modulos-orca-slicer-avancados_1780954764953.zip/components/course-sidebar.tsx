'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { useState } from 'react'
import { Check, ChevronDown, CircleDot } from 'lucide-react'
import { cn } from '@/lib/utils'
import { modulos } from '@/lib/course'
import { useProgresso } from '@/hooks/use-progresso'
import { ScrollArea } from '@/components/ui/scroll-area'

export function CourseSidebar({ onNavigate }: { onNavigate?: () => void }) {
  const pathname = usePathname()
  const { estaConcluida, carregado } = useProgresso()

  // Descobre módulo ativo pela URL
  const partes = pathname.split('/').filter(Boolean)
  const moduloAtivo = partes[0] === 'licao' ? partes[1] : undefined

  const [abertos, setAbertos] = useState<Record<string, boolean>>(() => {
    const init: Record<string, boolean> = {}
    modulos.forEach((m) => {
      init[m.slug] = moduloAtivo ? m.slug === moduloAtivo : m.numero === 1
    })
    return init
  })

  function toggle(slug: string) {
    setAbertos((p) => ({ ...p, [slug]: !p[slug] }))
  }

  return (
    <div className="flex h-full min-h-0 flex-1 flex-col">
      <div className="shrink-0 border-b border-border px-5 py-4">
        <Link
          href="/"
          onClick={onNavigate}
          className="flex items-center gap-2.5"
        >
          <div className="flex h-8 w-8 items-center justify-center rounded-md bg-primary text-primary-foreground">
            <CircleDot className="h-5 w-5" />
          </div>
          <div className="leading-tight">
            <p className="font-mono text-sm font-bold tracking-tight text-foreground">
              MESTRE ORCA
            </p>
            <p className="text-[11px] text-muted-foreground">
              Curso de Impressão 3D
            </p>
          </div>
        </Link>
      </div>

      <ScrollArea className="min-h-0 flex-1">
        <nav className="px-3 py-4">
          {modulos.map((m) => {
            const aberto = abertos[m.slug]
            const totalMod = m.licoes.length
            const concluidasMod = carregado
              ? m.licoes.filter((l) => estaConcluida(`${m.slug}/${l.slug}`))
                  .length
              : 0
            const completo = totalMod > 0 && concluidasMod === totalMod

            return (
              <div key={m.slug} className="mb-1">
                <button
                  onClick={() => toggle(m.slug)}
                  className={cn(
                    'flex w-full items-center gap-2 rounded-md px-2.5 py-2 text-left transition-colors hover:bg-muted',
                    moduloAtivo === m.slug && 'bg-muted',
                  )}
                >
                  <span
                    className={cn(
                      'flex h-6 w-6 shrink-0 items-center justify-center rounded font-mono text-[11px] font-bold',
                      completo
                        ? 'bg-primary text-primary-foreground'
                        : 'bg-secondary text-secondary-foreground',
                    )}
                  >
                    {completo ? <Check className="h-3.5 w-3.5" /> : m.numero}
                  </span>
                  <span className="flex-1 text-[13px] font-medium leading-tight text-foreground">
                    {m.titulo}
                  </span>
                  <ChevronDown
                    className={cn(
                      'h-4 w-4 shrink-0 text-muted-foreground transition-transform',
                      aberto && 'rotate-180',
                    )}
                  />
                </button>

                {aberto && (
                  <ul className="ml-3 mt-0.5 border-l border-border pl-3">
                    {m.licoes.map((l) => {
                      const href = `/licao/${m.slug}/${l.slug}`
                      const ativo = pathname === href
                      const feita = carregado && estaConcluida(`${m.slug}/${l.slug}`)
                      return (
                        <li key={l.slug}>
                          <Link
                            href={href}
                            onClick={onNavigate}
                            className={cn(
                              'flex items-center gap-2 rounded-md py-1.5 pl-2 pr-2 text-[13px] transition-colors hover:bg-muted',
                              ativo
                                ? 'font-medium text-primary'
                                : 'text-muted-foreground',
                            )}
                          >
                            <span
                              className={cn(
                                'flex h-4 w-4 shrink-0 items-center justify-center rounded-full border',
                                feita
                                  ? 'border-primary bg-primary text-primary-foreground'
                                  : 'border-border',
                              )}
                            >
                              {feita && <Check className="h-2.5 w-2.5" />}
                            </span>
                            <span className="leading-tight text-pretty">
                              {l.titulo}
                            </span>
                          </Link>
                        </li>
                      )
                    })}
                  </ul>
                )}
              </div>
            )
          })}
        </nav>
      </ScrollArea>
    </div>
  )
}
