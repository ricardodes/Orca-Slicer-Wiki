'use client'

import Link from 'next/link'
import { ArrowRight, BookOpen, Check, Layers } from 'lucide-react'
import { cn } from '@/lib/utils'
import { modulos } from '@/lib/course'
import { useProgresso } from '@/hooks/use-progresso'

const NIVEL_COR: Record<string, string> = {
  Iniciante: 'text-chart-2',
  Intermediário: 'text-chart-1',
  Avançado: 'text-primary',
  Especialista: 'text-destructive',
}

export function ModuleGrid() {
  const { estaConcluida, carregado } = useProgresso()

  return (
    <div className="grid gap-4 sm:grid-cols-2">
      {modulos.map((m) => {
        const total = m.licoes.length
        const feitas = carregado
          ? m.licoes.filter((l) => estaConcluida(`${m.slug}/${l.slug}`)).length
          : 0
        const completo = total > 0 && feitas === total
        const primeira = m.licoes[0]
        const href = primeira
          ? `/licao/${m.slug}/${primeira.slug}`
          : '/'

        return (
          <Link
            key={m.slug}
            href={href}
            className="group relative flex flex-col rounded-xl border border-border bg-card p-5 transition-all hover:border-primary/50 hover:shadow-lg hover:shadow-primary/5"
          >
            <div className="mb-3 flex items-center justify-between">
              <span
                className={cn(
                  'flex h-10 w-10 items-center justify-center rounded-lg font-mono text-sm font-bold',
                  completo
                    ? 'bg-primary text-primary-foreground'
                    : 'bg-secondary text-secondary-foreground',
                )}
              >
                {completo ? <Check className="h-5 w-5" /> : `0${m.numero}`.slice(-2)}
              </span>
              <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                <Layers className="h-3.5 w-3.5" />
                {total} lições
              </div>
            </div>

            <h3 className="text-pretty font-semibold leading-tight text-foreground">
              {m.titulo}
            </h3>
            <p className="mt-1 text-sm text-muted-foreground">{m.subtitulo}</p>
            <p className="mt-2 line-clamp-2 text-[13px] leading-relaxed text-muted-foreground/80">
              {m.descricao}
            </p>

            <div className="mt-4 flex items-center justify-between border-t border-border pt-3">
              <span className="text-xs font-medium text-muted-foreground">
                {carregado && feitas > 0
                  ? `${feitas}/${total} concluídas`
                  : 'Começar módulo'}
              </span>
              <ArrowRight className="h-4 w-4 text-primary transition-transform group-hover:translate-x-1" />
            </div>
          </Link>
        )
      })}
    </div>
  )
}

export function HomeProgressBanner() {
  const { totalConcluidas, carregado } = useProgresso()
  if (!carregado || totalConcluidas === 0) return null

  return (
    <div className="mb-6 flex items-center gap-3 rounded-lg border border-primary/30 bg-primary/5 px-4 py-3">
      <BookOpen className="h-5 w-5 text-primary" />
      <p className="text-sm text-foreground">
        Você já concluiu{' '}
        <span className="font-bold text-primary">{totalConcluidas}</span>{' '}
        {totalConcluidas === 1 ? 'lição' : 'lições'}. Continue de onde parou.
      </p>
    </div>
  )
}
