'use client'

import { useState } from 'react'
import { Menu } from 'lucide-react'
import { Sheet, SheetContent, SheetTitle, SheetTrigger } from '@/components/ui/sheet'
import { Button } from '@/components/ui/button'
import { CourseSidebar } from '@/components/course-sidebar'
import { ProgressoGlobal } from '@/components/progresso-global'

export function CourseShell({ children }: { children: React.ReactNode }) {
  const [open, setOpen] = useState(false)

  return (
    <div className="flex min-h-screen bg-background">
      {/* Sidebar desktop */}
      <aside className="sticky top-0 hidden h-screen w-80 shrink-0 border-r border-border bg-card lg:flex lg:flex-col">
        <CourseSidebar />
        <div className="border-t border-border p-4">
          <ProgressoGlobal />
        </div>
      </aside>

      <div className="flex min-w-0 flex-1 flex-col">
        {/* Topbar mobile */}
        <header className="sticky top-0 z-30 flex items-center justify-between border-b border-border bg-card/95 px-4 py-3 backdrop-blur lg:hidden">
          <Sheet open={open} onOpenChange={setOpen}>
            <SheetTrigger
              render={
                <Button
                  variant="outline"
                  size="icon"
                  aria-label="Abrir menu do curso"
                />
              }
            >
              <Menu className="h-5 w-5" />
            </SheetTrigger>
            <SheetContent side="left" className="w-80 p-0">
              <SheetTitle className="sr-only">Navegação do curso</SheetTitle>
              <div className="flex h-full flex-col">
                <CourseSidebar onNavigate={() => setOpen(false)} />
                <div className="border-t border-border p-4">
                  <ProgressoGlobal />
                </div>
              </div>
            </SheetContent>
          </Sheet>
          <span className="font-mono text-sm font-bold text-foreground">
            MESTRE ORCA
          </span>
          <div className="w-9" />
        </header>

        <main className="min-w-0 flex-1">{children}</main>
      </div>
    </div>
  )
}
