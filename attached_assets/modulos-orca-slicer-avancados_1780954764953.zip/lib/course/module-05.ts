import type { Modulo } from '@/lib/types'

export const modulo05: Modulo = {
  slug: 'calibracao',
  numero: 5,
  titulo: 'Calibração Completa',
  subtitulo: 'As ferramentas de calibração nativas do OrcaSlicer',
  descricao:
    'O OrcaSlicer tem calibrações embutidas (menu Calibration). Dominar Temperature Tower, Flow, Pressure Advance, Retraction, Input Shaper e os testes de qualidade é o que transforma uma impressora "ok" numa máquina afiada.',
  licoes: [
    {
      slug: 'temp-flow-pa',
      titulo: 'Temperature Tower, Flow Rate e Pressure Advance',
      resumo:
        'As três calibrações fundamentais que afetam diretamente a qualidade e a precisão.',
      duracao: '20 min',
      nivel: 'Avançado',
      intro: [
        'Calibrar é medir, não adivinhar. O OrcaSlicer gera modelos de teste prontos no menu Calibration. Você imprime, observa e ajusta — substituindo o "achismo" por dados.',
        'A ordem importa: temperatura primeiro (afeta tudo), depois fluxo, depois pressure advance.',
      ],
      secoes: [
        {
          titulo: 'Temperature Tower',
          conteudo: [
            'Imprime uma torre onde cada bloco usa uma temperatura diferente.',
            'Como interpretar: escolha o bloco com melhor equilíbrio entre adesão de camada, ponte, overhang e mínimo stringing.',
            'Como corrigir: defina a temperatura vencedora no perfil de filamento.',
          ],
        },
        {
          titulo: 'Flow Rate (calibração de fluxo)',
          conteudo: [
            'Imprime quadrados de parede única/topo sólido com pequenos ajustes de fluxo.',
            'Como interpretar: o flow correto deixa o topo liso, sem vãos (subextrusão) nem rugas/excesso (superextrusão).',
            'Processo em duas passadas (coarse + fine) no OrcaSlicer afina o valor.',
          ],
        },
        {
          titulo: 'Pressure Advance (Linear Advance)',
          conteudo: [
            'Compensa o atraso de pressão no bico, melhorando cantos e início/fim de extrusão (evita bolhas nos cantos e subextrusão no início das linhas).',
            'O teste imprime padrões com PA variável; escolhe-se o valor com cantos mais nítidos e extrusão uniforme.',
            'Klipper usa PRESSURE_ADVANCE; Marlin usa Linear Advance (M900).',
          ],
        },
      ],
      estrutura: {
        oQueFaz:
          'Ajusta temperatura, quantidade de material e dinâmica de pressão para extrusão precisa.',
        comoFunciona:
          'Cada teste isola uma variável e a varia em incrementos, permitindo leitura visual do ponto ótimo.',
        quandoUsar:
          'Sempre ao usar um filamento novo (marca/cor) ou após mudanças de hardware.',
        quandoEvitar:
          'Não pule etapas nem calibre PA antes de fluxo e temperatura — os resultados ficam mascarados.',
        impactoResistencia:
          'Fluxo e temperatura corretos garantem adesão entre linhas/camadas — base da resistência.',
        impactoQualidade:
          'PA elimina blobs em cantos; fluxo correto dá topos lisos; temperatura define ponte/overhang.',
        impactoTempo:
          'Indireto: PA permite manter velocidade alta com qualidade.',
        errosComuns: [
          'Calibrar PA antes do fluxo/temperatura.',
          'Reutilizar o flow de uma cor em outra marca.',
        ],
        comoCorrigir: [
          'Siga a ordem: temperatura → fluxo → pressure advance.',
          'Recalibre o fluxo a cada filamento novo.',
        ],
        casosReais: [
          'Cantos com "orelhas" e bolhas somem ao calibrar Pressure Advance corretamente.',
        ],
      },
      exercicios: [
        'Rode a Temperature Tower do seu filamento atual e escolha a temperatura vencedora.',
        'Calibre o Flow em duas passadas e anote o flow ratio final.',
      ],
      testes: [
        'Qual a ordem correta de calibração e por quê?',
        'O que o Pressure Advance corrige?',
      ],
      desafio:
        'Pegue um filamento nunca calibrado e produza um perfil afinado completo (temp + flow + PA), documentando os valores e o raciocínio.',
    },
    {
      slug: 'retraction-input-shaper-testes',
      titulo: 'Retraction, Input Shaper e Testes de Qualidade',
      resumo:
        'Retração, Input Shaper, VFA, Maximum Flow, Tolerance, Bridging e Overhang.',
      duracao: '22 min',
      nivel: 'Especialista',
      intro: [
        'Estas calibrações eliminam os defeitos mais teimosos: stringing (retração), ghosting (input shaper), encaixes errados (tolerance) e overhangs falhos. São o polimento final do especialista.',
      ],
      secoes: [
        {
          titulo: 'Retraction',
          conteudo: [
            'Puxa o filamento de volta nos deslocamentos para evitar oozing/stringing.',
            'Teste de retração varia distância e velocidade. Bowden precisa de mais distância (4–6 mm) que direct drive (0,5–2 mm).',
            'Excesso de retração causa entupimento e cliques no extrusor.',
          ],
        },
        {
          titulo: 'Input Shaper',
          conteudo: [
            'Mede e cancela as frequências de vibração da máquina, eliminando ghosting/ringing e permitindo acelerações altas.',
            'No Klipper, usa acelerômetro (ADXL345); o teste do OrcaSlicer ajuda a validar visualmente.',
          ],
        },
        {
          titulo: 'Testes de qualidade',
          conteudo: [
            'VFA (Vertical Fine Artifacts): detecta padrões finos nas paredes ligados a vibração/mecânica.',
            'Maximum Flow: encontra o teto real de mm³/s antes da subextrusão.',
            'Tolerance Test: calibra folgas para encaixes (pinos/furos).',
            'Bridging Test: valida a capacidade de fazer pontes (fan + velocidade).',
            'Overhang Test: mostra até que ângulo a peça imprime sem suporte.',
          ],
        },
      ],
      estrutura: {
        oQueFaz:
          'Eliminam stringing, vibração, erros de encaixe e validam limites de ponte/overhang.',
        comoFunciona:
          'Cada teste estressa uma condição específica (deslocamento, vibração, vazão, folga, ângulo) e revela o limite.',
        quandoUsar:
          'Retraction e flow ao trocar filamento; Input Shaper ao montar/atualizar a máquina; tolerance antes de peças de encaixe.',
        quandoEvitar:
          'Não exagere na retração buscando zero stringing — entope e desgasta o filamento.',
        impactoResistencia:
          'Maximum Flow garante que velocidade não cause subextrusão (que enfraquece a peça).',
        impactoQualidade:
          'Input Shaper e VFA dão paredes limpas; retração elimina fios; tolerance dá encaixes perfeitos.',
        impactoTempo:
          'Input Shaper é o que libera velocidade/aceleração altas mantendo qualidade.',
        errosComuns: [
          'Retração excessiva entupindo o bico.',
          'Acelerar sem Input Shaper e culpar o slicer pelo ghosting.',
          'Imprimir encaixes sem tolerance test e tudo ficar apertado ou frouxo.',
        ],
        comoCorrigir: [
          'Reduza a retração ao mínimo que elimina stringing.',
          'Calibre Input Shaper antes de subir aceleração.',
          'Aplique a folga do tolerance test no CAD/slicer.',
        ],
        casosReais: [
          'Duas peças que deveriam encaixar saem travadas; o tolerance test revela que 0,2 mm de folga resolve.',
        ],
      },
      tabelas: [
        {
          titulo: 'Retração: Bowden vs Direct Drive',
          colunas: ['Tipo', 'Distância típica', 'Velocidade'],
          linhas: [
            ['Direct Drive', '0,5–2 mm', '25–45 mm/s'],
            ['Bowden', '4–6 mm', '30–60 mm/s'],
          ],
        },
      ],
      exercicios: [
        'Rode o teste de retração e elimine o stringing sem exagerar na distância.',
        'Imprima o Tolerance Test e descubra a folga ideal de encaixe da sua máquina.',
        'Rode o Overhang Test e anote o ângulo máximo sem suporte.',
      ],
      testes: [
        'O que o Input Shaper resolve?',
        'Por que retração demais é tão ruim quanto de menos?',
        'Para que serve o Maximum Flow test?',
      ],
      desafio:
        'Sua máquina apresenta ghosting nas paredes e stringing entre torres. Crie um plano de calibração passo a passo (qual teste, em que ordem, o que ajustar) para zerar ambos os defeitos.',
    },
  ],
}
