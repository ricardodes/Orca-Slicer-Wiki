import type { Modulo } from '@/lib/types'

export const modulo07: Modulo = {
  slug: 'otimizacao',
  numero: 7,
  titulo: 'Otimização Extrema',
  subtitulo: 'Menos tempo, menos material, mais resistência',
  descricao:
    'Estratégias para reduzir filamento e tempo, aumentar resistência, melhorar acabamento e reduzir suportes e falhas — com tabelas de ganhos e perdas.',
  licoes: [
    {
      slug: 'tempo-material-resistencia',
      titulo: 'Reduzir Tempo e Material sem Perder Resistência',
      resumo:
        'As alavancas reais de otimização e os trade-offs de cada decisão.',
      duracao: '18 min',
      nivel: 'Especialista',
      intro: [
        'Otimização é a arte do trade-off consciente. Quase toda economia tem um custo — o especialista sabe qual custo é aceitável para cada peça.',
        'As maiores alavancas: orientação (grátis), altura de camada (tempo), paredes vs infill (resistência/peso), suporte (material/tempo) e velocidade de infill/travel (tempo).',
      ],
      secoes: [
        {
          titulo: 'Reduzir tempo',
          conteudo: [
            'Aumente a altura de camada onde a qualidade não importa (maior impacto).',
            'Acelere infill e travel; mantenha a parede externa lenta.',
            'Reduza ou troque o suporte por tree/organic.',
            'Use bico maior (0,6 mm) para peças funcionais.',
          ],
        },
        {
          titulo: 'Reduzir material',
          conteudo: [
            'Baixe a densidade do infill e use padrões eficientes (gyroid/adaptive cubic).',
            'Minimize suporte (orientação + painting).',
            'Use infill Lightning em peças puramente decorativas.',
          ],
        },
        {
          titulo: 'Aumentar resistência',
          conteudo: [
            'Priorize paredes sobre infill (mais resistência por grama).',
            'Oriente a carga ao longo das camadas.',
            'Aumente a temperatura (dentro do seguro) para melhor adesão entre camadas.',
            'Considere material melhor (PETG/ABS) antes de "encher" a peça de plástico.',
          ],
        },
      ],
      estrutura: {
        oQueFaz:
          'Maximiza o valor de cada impressão equilibrando tempo, custo, resistência e acabamento.',
        comoFunciona:
          'Cada parâmetro move o ponto de equilíbrio; otimizar é escolher conscientemente o que sacrificar.',
        quandoUsar:
          'Sempre, mas a prioridade muda: protótipo (tempo), produto à venda (acabamento + custo), peça funcional (resistência).',
        quandoEvitar:
          'Não otimize cegamente por tempo em peças estruturais nem por resistência em peças decorativas.',
        impactoResistencia:
          'Paredes e orientação são as maiores alavancas; infill alto é a alavanca menos eficiente.',
        impactoQualidade:
          'Velocidade/altura de camada altas economizam tempo mas custam acabamento.',
        impactoTempo:
          'Altura de camada e suporte dominam o tempo total.',
        impactoFilamento:
          'Suporte e densidade de infill dominam o consumo.',
        errosComuns: [
          'Aumentar infill achando que ganha resistência (ganha peso e tempo).',
          'Reduzir paredes para economizar tempo e enfraquecer a peça.',
        ],
        comoCorrigir: [
          'Troque infill alto por mais paredes.',
          'Otimize tempo via altura de camada, infill/travel e suporte — não via parede externa.',
        ],
        casosReais: [
          'Reduzir um lote de 20% para 15% de infill e trocar para gyroid cortou 18% do tempo e 22% do material com perda de resistência desprezível.',
        ],
      },
      tabelas: [
        {
          titulo: 'Alavancas de otimização: ganhos e perdas',
          colunas: ['Ação', 'Ganha', 'Perde'],
          linhas: [
            ['+ Altura de camada', 'Tempo', 'Detalhe vertical'],
            ['+ Paredes / - Infill', 'Resistência/peso', 'Pouco tempo'],
            ['Tree/Organic support', 'Tempo/material', 'Nada relevante'],
            ['+ Velocidade infill/travel', 'Tempo', 'Quase nada'],
            ['+ Velocidade parede externa', 'Pouco tempo', 'Muita qualidade'],
            ['Bico 0,6 mm', 'Tempo/resistência', 'Detalhe fino'],
          ],
        },
      ],
      exercicios: [
        'Pegue uma peça e crie 3 perfis: máxima velocidade, máxima resistência e equilíbrio. Compare as métricas.',
        'Reduza o material de uma peça em 20% sem perder resistência percebida — documente o que mudou.',
      ],
      testes: [
        'Qual a alavanca mais eficiente de resistência por grama?',
        'Por que aumentar a velocidade da parede externa é a pior otimização de tempo?',
      ],
      desafio:
        'Crie uma tabela comparativa de 3 perfis (rápido, forte, equilibrado) para a mesma peça, com tempo, material e resistência estimada, e recomende qual usar para venda em escala.',
    },
  ],
}
