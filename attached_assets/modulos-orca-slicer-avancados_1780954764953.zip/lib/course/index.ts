import type { Modulo, Licao } from '@/lib/types'
import { modulo01 } from './module-01'
import { modulo02 } from './module-02'
import { modulo03 } from './module-03'
import { modulo04 } from './module-04'
import { modulo05 } from './module-05'
import { modulo06 } from './module-06'
import { modulo07 } from './module-07'
import { modulo08 } from './module-08'
import { modulo09 } from './module-09'
import { modulo10 } from './module-10'
import { modulo11 } from './module-11'
import { modulo12 } from './module-12'
import { modulo13 } from './module-13'
import { modulo14 } from './module-14'
import { modulo15 } from './module-15'
import { modulo16 } from './module-16'

export const modulos: Modulo[] = [
  modulo01,
  modulo02,
  modulo03,
  modulo04,
  modulo05,
  modulo06,
  modulo07,
  modulo08,
  modulo09,
  modulo10,
  modulo11,
  modulo12,
  modulo13,
  modulo14,
  modulo15,
  modulo16,
]

export const totalLicoes = modulos.reduce((acc, m) => acc + m.licoes.length, 0)

export function getModulo(slug: string): Modulo | undefined {
  return modulos.find((m) => m.slug === slug)
}

export function getLicao(
  moduloSlug: string,
  licaoSlug: string,
): { modulo: Modulo; licao: Licao } | undefined {
  const modulo = getModulo(moduloSlug)
  if (!modulo) return undefined
  const licao = modulo.licoes.find((l) => l.slug === licaoSlug)
  if (!licao) return undefined
  return { modulo, licao }
}

export type FlatLicao = {
  moduloSlug: string
  moduloNumero: number
  moduloTitulo: string
  licao: Licao
  globalIndex: number
}

export function getFlatLicoes(): FlatLicao[] {
  const flat: FlatLicao[] = []
  let i = 0
  for (const m of modulos) {
    for (const l of m.licoes) {
      flat.push({
        moduloSlug: m.slug,
        moduloNumero: m.numero,
        moduloTitulo: m.titulo,
        licao: l,
        globalIndex: i,
      })
      i++
    }
  }
  return flat
}

export function getAdjacentLicoes(moduloSlug: string, licaoSlug: string) {
  const flat = getFlatLicoes()
  const idx = flat.findIndex(
    (f) => f.moduloSlug === moduloSlug && f.licao.slug === licaoSlug,
  )
  return {
    anterior: idx > 0 ? flat[idx - 1] : undefined,
    proxima: idx < flat.length - 1 ? flat[idx + 1] : undefined,
    atual: idx,
    total: flat.length,
  }
}

export function getLicaoId(moduloSlug: string, licaoSlug: string): string {
  return `${moduloSlug}/${licaoSlug}`
}

/**
 * Nome do arquivo de imagem esperado para uma lição.
 * Basta salvar a imagem em public/imagens-licoes/ com este nome
 * que ela aparece automaticamente no topo da lição.
 */
export function getImagemArquivo(
  moduloSlug: string,
  licaoSlug: string,
): string {
  return `${moduloSlug}__${licaoSlug}.jpg`
}

export function getImagemPath(moduloSlug: string, licaoSlug: string): string {
  return `/imagens-licoes/${getImagemArquivo(moduloSlug, licaoSlug)}`
}

/**
 * Monta o prompt sugerido para gerar a imagem de uma lição em uma IA externa.
 */
export function getImagemPrompt(modulo: Modulo, licao: Licao): string {
  return [
    `Ilustração técnica e educativa sobre impressão 3D (OrcaSlicer), tema: "${licao.titulo}".`,
    `Contexto do módulo: ${modulo.titulo} — ${modulo.subtitulo}.`,
    `Resumo da lição: ${licao.resumo}`,
    `Estilo: imagem realista de impressora 3D / detalhe de peça impressa / interface do slicer quando fizer sentido, iluminação suave, cores escuras com destaque em laranja, alta nitidez, composição limpa e profissional, proporção 16:9, sem texto sobreposto.`,
  ].join(' ')
}
