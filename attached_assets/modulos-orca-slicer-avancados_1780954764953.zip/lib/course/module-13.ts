import type { Modulo } from '@/lib/types'

export const modulo13: Modulo = {
  slug: 'tolerancias-funcionais',
  numero: 13,
  titulo: 'Tolerâncias e Projetos Funcionais',
  subtitulo: 'Peças mecânicas que encaixam de verdade',
  descricao:
    'Domine folgas, compensação dimensional e todos os ajustes (Horizontal Expansion, XY e Elephant Foot) para fabricar press fit, snap fit, roscas, dobradiças e engrenagens funcionais.',
  licoes: [
    {
      slug: 'tolerancias-folgas',
      titulo: 'Tolerâncias, folgas e compensação dimensional',
      resumo:
        'Por que a peça sai diferente do CAD e como compensar com precisão.',
      duracao: '22 min',
      nivel: 'Avançado',
      intro: [
        'Em peças mecânicas o sucesso depende de centésimos de milímetro. Uma peça que encaixa no CAD pode travar ou ficar frouxa na vida real.',
        'A impressão FDM tende a deixar furos menores e pinos maiores que o projetado, por causa do alargamento da extrusão e da contração do material.',
      ],
      secoes: [
        {
          titulo: 'O que são tolerâncias e folgas',
          conteudo: [
            'Tolerância é a variação aceitável de uma medida. Folga (clearance) é o espaço deixado entre duas peças que se encaixam.',
            'Folga típica para encaixe deslizante: 0,2–0,4 mm no total (0,1–0,2 mm por lado).',
            'Folga para encaixe fixo (press fit): 0,0–0,1 mm — quase justo, com leve interferência.',
          ],
        },
        {
          titulo: 'Compensação dimensional',
          conteudo: [
            'Imprima um cubo de calibração (ex.: 20 mm) e meça com paquímetro. A diferença é o seu erro sistemático.',
            'Use essa diferença para ajustar Horizontal Expansion / XY Compensation no perfil.',
            'Furos costumam precisar de compensação positiva (aumentar diâmetro no CAD ou via XY compensation negativa nas paredes internas).',
          ],
        },
      ],
      tabelas: [
        {
          titulo: 'Folgas recomendadas por tipo de encaixe',
          colunas: ['Tipo de encaixe', 'Folga total', 'Resultado'],
          linhas: [
            ['Press fit (fixo)', '0,0–0,1 mm', 'Entra sob pressão, não solta'],
            ['Deslizante leve', '0,2 mm', 'Desliza com pouca folga'],
            ['Deslizante livre', '0,3–0,4 mm', 'Move-se livremente'],
            ['Rosca funcional', '0,3–0,5 mm', 'Enrosca sem travar'],
          ],
        },
      ],
      estrutura: {
        oQueFaz:
          'Compensa o desvio entre a medida projetada e a impressa para garantir encaixes funcionais.',
        comoFunciona:
          'Mede-se o erro sistemático em uma peça-teste e aplica-se a compensação no perfil ou no CAD.',
        impactoQualidade: 'Define se a peça mecânica funciona ou não.',
      },
      exercicios: [
        'Imprima um cubo de 20 mm, meça e calcule o erro dimensional da sua máquina.',
        'Imprima um teste de folgas (gap test) e descubra a folga ideal do seu setup.',
      ],
      testes: [
        'Qual a diferença entre tolerância e folga?',
        'Qual folga usar para um encaixe deslizante livre?',
      ],
    },
    {
      slug: 'compensacoes-orca',
      titulo: 'Horizontal Expansion, XY e Elephant Foot Compensation',
      resumo:
        'Os três parâmetros do OrcaSlicer que corrigem dimensões e a base inchada.',
      duracao: '22 min',
      nivel: 'Avançado',
      intro: [
        'O OrcaSlicer tem três compensações distintas que resolvem problemas dimensionais diferentes. Confundi-las é um erro comum.',
      ],
      secoes: [
        {
          titulo: 'Os três parâmetros',
          conteudo: [
            'Horizontal Expansion / XY Compensation: encolhe ou expande as paredes no plano XY. Negativo deixa a peça menor (furos maiores, pinos menores).',
            'Elephant Foot Compensation: corrige a primeira camada esmagada que deixa a base mais larga (a "pata de elefante").',
            'Hole/Contour Compensation: alguns perfis permitem compensar furos e contornos de forma independente.',
          ],
        },
        {
          titulo: 'Como aplicar cada um',
          conteudo: [
            'Base mais larga que o resto da peça → Elephant Foot Compensation (0,1–0,3 mm).',
            'Toda a peça maior que o CAD → XY Compensation negativa.',
            'Furos ficando apertados → compense aumentando o furo no CAD ou ajustando a compensação de contorno interno.',
          ],
        },
      ],
      tabelas: [
        {
          titulo: 'Problema dimensional x compensação',
          colunas: ['Problema', 'Parâmetro', 'Valor típico'],
          linhas: [
            ['Base inchada (elephant foot)', 'Elephant Foot Comp.', '0,1–0,3 mm'],
            ['Peça toda maior que o CAD', 'XY Compensation', '-0,05 a -0,15 mm'],
            ['Furos apertados', 'Contorno interno / CAD', '+0,1–0,2 mm no Ø'],
            ['Pinos grossos demais', 'XY Compensation', 'Negativa'],
          ],
        },
      ],
      estrutura: {
        oQueFaz:
          'Ajusta dimensões finais e corrige a deformação da primeira camada.',
        errosComuns: [
          'Usar XY Compensation para corrigir elephant foot (parâmetro errado).',
          'Compensar a peça inteira quando só a base estava inchada.',
        ],
        comoCorrigir: [
          'Diagnostique se o erro é só na base (Elephant Foot) ou em toda a peça (XY).',
          'Ajuste um parâmetro de cada vez e remeça.',
        ],
      },
      exercicios: [
        'Provoque elephant foot abaixando o Z-offset e depois corrija com a compensação certa.',
        'Ajuste XY Compensation até um pino de 10 mm sair com 10,00 mm reais.',
      ],
      testes: [
        'Qual compensação corrige a base mais larga?',
        'Qual parâmetro usar quando a peça inteira sai maior que o CAD?',
      ],
    },
    {
      slug: 'press-snap-fit',
      titulo: 'Press Fit e Snap Fit',
      resumo:
        'Encaixes por pressão e por clipe: conceito, aplicação e correções.',
      duracao: '20 min',
      nivel: 'Especialista',
      intro: [
        'Press fit e snap fit são as duas formas de unir peças impressas sem parafusos. Ambos vivem ou morrem pela folga e pela orientação.',
      ],
      secoes: [
        {
          titulo: 'Press Fit',
          conteudo: [
            'Conceito: o pino é levemente maior que o furo e entra por interferência.',
            'Aplicação: pinos de montagem, buchas, eixos fixos.',
            'Folga: 0,0 a -0,05 mm (interferência). Imprima paredes grossas ao redor do furo para não rachar.',
            'Erro comum: interferência grande demais racha a peça. Correção: aumentar a folga ou as paredes.',
          ],
        },
        {
          titulo: 'Snap Fit',
          conteudo: [
            'Conceito: uma lingueta flexível que dobra e trava num ressalto (clipe).',
            'Aplicação: tampas de caixa, clipes de bateria, carcaças.',
            'Orientação é tudo: a lingueta NÃO pode ter a flexão na direção das camadas (delamina). Imprima de forma que a flexão seja no plano XY.',
            'Erro comum: clipe quebra na primeira abertura → orientação errada ou material rígido demais (use PETG/PLA+ em vez de PLA puro).',
          ],
        },
      ],
      estrutura: {
        oQueFaz:
          'Permite montagem sem fixadores usando interferência (press) ou flexão elástica (snap).',
        impactoResistencia:
          'A orientação define se o clipe sobrevive — flexão deve ocorrer no plano das camadas.',
        errosComuns: [
          'Snap fit impresso com a flexão no sentido Z (delamina).',
          'Press fit com interferência excessiva que racha o furo.',
        ],
        comoCorrigir: [
          'Reoriente o snap fit para flexionar no XY.',
          'Aumente paredes do furo e ajuste a folga do press fit.',
        ],
      },
      exercicios: [
        'Imprima um snap fit em duas orientações e teste qual aguenta mais aberturas.',
        'Calibre a interferência de um press fit testando -0,05, 0,0 e +0,05 mm.',
      ],
      testes: [
        'Por que a orientação é crítica no snap fit?',
        'Qual a folga típica de um press fit por interferência?',
      ],
    },
    {
      slug: 'roscas-dobradicas-engrenagens',
      titulo: 'Roscas, dobradiças e engrenagens impressas',
      resumo:
        'Mecanismos funcionais e os projetos práticos do módulo.',
      duracao: '26 min',
      nivel: 'Especialista',
      intro: [
        'Estes são os três mecanismos clássicos da impressão funcional. Cada um tem segredos de orientação e folga.',
      ],
      secoes: [
        {
          titulo: 'Roscas impressas',
          conteudo: [
            'Imprima roscas na vertical sempre que possível (o eixo da rosca apontando para cima) para um perfil mais limpo.',
            'Folga entre rosca interna e externa: 0,3–0,5 mm. Roscas grandes (passo > 2 mm) funcionam muito melhor.',
            'Evite roscas finas (M3, M4) impressas — use insertos de latão ou parafuse direto no plástico.',
          ],
        },
        {
          titulo: 'Dobradiças impressas',
          conteudo: [
            'Dobradiça de pino: imprima o corpo e o pino separados com folga de 0,3–0,4 mm.',
            'Dobradiça print-in-place: imprima já montada deixando a folga no modelo; oriente o eixo no plano XY.',
            'Living hinge: dobradiça de filme fino que flexiona — exige material flexível e camada fina; PP e PETG funcionam melhor que PLA.',
          ],
        },
        {
          titulo: 'Engrenagens e encaixes',
          conteudo: [
            'Engrenagens precisam de dentes bem definidos: parede externa lenta e camada fina (0,12–0,16 mm).',
            'Deixe folga de backlash de ~0,2 mm entre dentes que engrenam.',
            'Oriente o eixo da engrenagem no Z e a face dos dentes no XY para máxima precisão de perfil.',
          ],
        },
      ],
      tabelas: [
        {
          titulo: 'Mecanismo x folga x orientação',
          colunas: ['Mecanismo', 'Folga típica', 'Orientação ideal'],
          linhas: [
            ['Rosca', '0,3–0,5 mm', 'Eixo na vertical (Z)'],
            ['Dobradiça de pino', '0,3–0,4 mm', 'Eixo no plano XY'],
            ['Print-in-place', '0,3–0,4 mm', 'Articulação no XY'],
            ['Engrenagem', '0,2 mm backlash', 'Eixo no Z, dentes no XY'],
          ],
        },
      ],
      estrutura: {
        oQueFaz:
          'Cria mecanismos que giram, enroscam e dobram de forma funcional.',
        impactoResistencia:
          'Orientação correta evita delaminação em pinos e dentes.',
        casosReais: [
          'Uma dobradiça print-in-place falhou por estar com o eixo no Z; reorientada no XY, passou a abrir mil vezes sem quebrar.',
        ],
      },
      exercicios: [
        'PROJETO — Caixa com tampa: modele uma caixa com tampa em snap fit e imprima com a folga calibrada.',
        'PROJETO — Engrenagem: imprima um par de engrenagens com 0,2 mm de backlash e teste o engate.',
        'PROJETO — Dobradiça: imprima uma dobradiça print-in-place e valide a folga.',
        'PROJETO — Rosca funcional: imprima parafuso e porca com passo grande e folga de 0,4 mm.',
      ],
      testes: [
        'Por que imprimir roscas na vertical?',
        'O que é backlash em uma engrenagem e qual folga usar?',
        'Qual a melhor orientação para uma dobradiça print-in-place?',
      ],
      desafio:
        'Projete e imprima uma caixa com tampa que feche por snap fit, com uma dobradiça print-in-place integrada e um fecho roscado. Tudo deve funcionar de primeira: calibre folga, elephant foot e orientação antes de imprimir. Documente as folgas usadas em cada interface.',
      perguntas: [
        {
          pergunta: 'Minha rosca M4 impressa não funciona. Por quê?',
          resposta:
            'Roscas muito finas como M4 têm detalhe menor que a resolução prática do FDM e travam ou espanam. Use roscas de passo grande (≥ 2 mm), insertos de latão ou parafuse diretamente no plástico com furo guia.',
        },
        {
          pergunta: 'Meu snap fit quebra sempre. Qual o erro mais provável?',
          resposta:
            'Orientação. Se a lingueta flexiona na direção das camadas (Z), ela delamina e quebra. Reoriente para que a flexão ocorra no plano XY e prefira PLA+ ou PETG, que toleram mais deformação que o PLA puro.',
        },
      ],
    },
  ],
}
