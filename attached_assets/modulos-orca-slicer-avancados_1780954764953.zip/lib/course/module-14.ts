import type { Modulo } from '@/lib/types'

export const modulo14: Modulo = {
  slug: 'resolucao-problemas',
  numero: 14,
  titulo: 'Resolução de Problemas Avançada',
  subtitulo: 'Diagnóstico e cura de qualquer defeito',
  descricao:
    'Um manual de diagnóstico para os principais defeitos de FDM: sintomas, causas, diagnóstico e solução para stringing, warping, delaminação, extrusão, layer shift, Z banding, clogs e mais.',
  licoes: [
    {
      slug: 'defeitos-superficie',
      titulo: 'Stringing, Ghosting, Ringing e Z Banding',
      resumo: 'Defeitos visuais de superfície: como reconhecer e corrigir.',
      duracao: '22 min',
      nivel: 'Avançado',
      intro: [
        'Defeitos de superfície raramente afetam a resistência, mas arruínam a aparência e o valor de venda.',
        'Cada um tem uma assinatura visual distinta — aprender a "ler" a peça é o que diferencia o profissional.',
      ],
      secoes: [
        {
          titulo: 'Stringing (fios)',
          conteudo: [
            'Sintomas: fios finos de plástico ligando partes separadas da peça, como teia.',
            'Causas: retração insuficiente, temperatura alta, filamento úmido (principalmente PETG).',
            'Diagnóstico: imprima uma torre de stringing; piora com filamento úmido.',
            'Solução: secar o filamento, calibrar retração, reduzir temperatura, ativar Wipe e Coasting.',
          ],
        },
        {
          titulo: 'Ghosting e Ringing',
          conteudo: [
            'Sintomas: ecos/sombras repetidas após cada quina.',
            'Causas: aceleração alta sem Input Shaper, frame pouco rígido, correias frouxas.',
            'Diagnóstico: padrão de teste de ringing; ecos aparecem depois de mudanças de direção.',
            'Solução: calibrar Input Shaper, reduzir aceleração, apertar correias.',
          ],
        },
        {
          titulo: 'Z Banding',
          conteudo: [
            'Sintomas: faixas horizontais regulares ao longo da altura.',
            'Causas: fuso/barra Z empenado, acoplador defeituoso, variação de temperatura.',
            'Diagnóstico: as faixas se repetem em intervalos constantes ligados ao passo do fuso.',
            'Solução: alinhar/lubrificar o eixo Z, verificar acoplador, estabilizar temperatura.',
          ],
        },
      ],
      tabelas: [
        {
          titulo: 'Defeito de superfície — diagnóstico rápido',
          colunas: ['Defeito', 'Sintoma', 'Solução principal'],
          linhas: [
            ['Stringing', 'Fios entre partes', 'Secar + calibrar retração'],
            ['Ghosting', 'Ecos após quinas', 'Input Shaper'],
            ['Z Banding', 'Faixas horizontais', 'Eixo Z / temperatura'],
          ],
        },
      ],
      estrutura: {
        oQueFaz: 'Identifica e corrige defeitos puramente visuais de superfície.',
        impactoQualidade: 'Alto no valor estético e comercial.',
      },
      exercicios: [
        'Imprima uma torre de stringing antes e depois de secar o filamento.',
        'Classifique 3 fotos de defeitos como stringing, ghosting ou z banding.',
      ],
      testes: [
        'Como diferenciar ghosting de z banding pela aparência?',
        'Qual a causa nº1 de stringing em PETG?',
      ],
    },
    {
      slug: 'defeitos-extrusao',
      titulo: 'Under Extrusion, Over Extrusion, Clogs e Heat Creep',
      resumo: 'Problemas de fluxo de material: pouco, demais ou entupido.',
      duracao: '24 min',
      nivel: 'Avançado',
      intro: [
        'Quando o fluxo de material está errado, nada mais funciona direito. Estes são os defeitos da extrusão.',
      ],
      secoes: [
        {
          titulo: 'Under Extrusion (subextrusão)',
          conteudo: [
            'Sintomas: linhas finas, falhas, buracos no topo (pillowing), camadas com gaps.',
            'Causas: flow baixo, MVF ultrapassado, bico parcialmente entupido, temperatura baixa.',
            'Diagnóstico: paredes que não se tocam, peça mais leve que o esperado.',
            'Solução: calibrar flow, respeitar o MVF, subir temperatura, limpar bico.',
          ],
        },
        {
          titulo: 'Over Extrusion (sobre-extrusão)',
          conteudo: [
            'Sintomas: paredes infladas, dimensões maiores, blobs, topo rugoso.',
            'Causas: flow alto, e-steps descalibrados, temperatura alta.',
            'Diagnóstico: peça maior que o CAD mesmo com XY ok.',
            'Solução: calibrar flow/e-steps, reduzir temperatura.',
          ],
        },
        {
          titulo: 'Clogs e Heat Creep',
          conteudo: [
            'Clog: entupimento do bico — parcial (subextrusão) ou total (nada sai).',
            'Heat Creep: o calor sobe pelo heatbreak e amolece o filamento antes da hora, entupindo o conjunto frio.',
            'Causas do heat creep: cooler do hotend fraco, retração excessiva, pausas longas com bico quente.',
            'Solução: melhorar o cooling do hotend, reduzir retração, fazer cold pull para limpar.',
          ],
        },
      ],
      tabelas: [
        {
          titulo: 'Extrusão — sintoma x causa x ação',
          colunas: ['Defeito', 'Causa típica', 'Ação'],
          linhas: [
            ['Subextrusão', 'Flow baixo / clog / MVF', 'Calibrar flow, limpar, respeitar MVF'],
            ['Sobre-extrusão', 'Flow alto / e-steps', 'Calibrar flow e e-steps'],
            ['Clog', 'Sujeira / temp baixa', 'Cold pull, limpar bico'],
            ['Heat creep', 'Cooler fraco / retração', 'Melhorar cooling, - retração'],
          ],
        },
      ],
      estrutura: {
        oQueFaz: 'Restaura o fluxo correto de material.',
        errosComuns: [
          'Aumentar a velocidade ignorando o MVF e provocar subextrusão.',
          'Trocar o bico sem investigar heat creep, que volta a entupir.',
        ],
        comoCorrigir: [
          'Calibre flow e e-steps com testes do OrcaSlicer.',
          'Faça cold pull e melhore o cooling do hotend.',
        ],
      },
      exercicios: [
        'Rode a calibração de flow do OrcaSlicer e ajuste o valor.',
        'Faça um cold pull e inspecione a sujeira removida.',
      ],
      testes: [
        'O que é heat creep e como evitá-lo?',
        'Como distinguir subextrusão por clog de subextrusão por MVF?',
      ],
    },
    {
      slug: 'defeitos-adesao-estrutura',
      titulo: 'Warping, Delaminação, Layer Shift e falhas de adesão',
      resumo: 'Defeitos estruturais que comprometem a peça e como resolvê-los.',
      duracao: '24 min',
      nivel: 'Especialista',
      intro: [
        'Estes defeitos não só estragam a aparência — eles fazem a peça falhar ou se soltar da mesa no meio da impressão.',
      ],
      secoes: [
        {
          titulo: 'Warping e falhas de adesão',
          conteudo: [
            'Sintomas: cantos levantando, peça descolando da mesa.',
            'Causas: contração do material (ABS/ASA), mesa fria/suja, cooling alto, ausência de câmara.',
            'Solução: mesa limpa e nivelada, temperatura de mesa correta, brim/raft, reduzir fan, usar enclosure para ABS.',
          ],
        },
        {
          titulo: 'Delaminação',
          conteudo: [
            'Sintomas: camadas se separando, rachaduras ao longo da altura.',
            'Causas: temperatura baixa, cooling excessivo, velocidade alta demais entre camadas.',
            'Solução: aumentar temperatura, reduzir fan (em ABS/PETG), reduzir velocidade, orientar a carga no plano das camadas.',
          ],
        },
        {
          titulo: 'Layer Shift',
          conteudo: [
            'Sintomas: camadas deslocadas lateralmente a partir de certa altura.',
            'Causas: perda de passos por aceleração alta, correia frouxa, colisão com a peça, corrente do driver baixa.',
            'Solução: reduzir aceleração/velocidade, apertar correias, aumentar corrente do motor, verificar obstáculos.',
          ],
        },
      ],
      tabelas: [
        {
          titulo: 'Defeito estrutural — diagnóstico',
          colunas: ['Defeito', 'Sintoma', 'Solução principal'],
          linhas: [
            ['Warping', 'Cantos levantam', 'Adesão + câmara + menos fan'],
            ['Delaminação', 'Camadas separam', '+ temperatura, - fan/velocidade'],
            ['Layer shift', 'Camadas deslocadas', '- aceleração, correias, corrente'],
            ['Adesão falha', 'Solta da mesa', 'Mesa limpa/nivelada, brim'],
          ],
        },
      ],
      estrutura: {
        oQueFaz: 'Garante que a peça permaneça presa e coesa do início ao fim.',
        impactoResistencia: 'Delaminação e warping comprometem diretamente a integridade.',
        casosReais: [
          'Peça de ABS empenando nos cantos foi resolvida fechando a câmara e desligando o fan.',
        ],
      },
      exercicios: [
        'Provoque warping com fan alto em ABS e corrija fechando a câmara.',
        'Diagnostique uma peça com layer shift: liste 3 causas possíveis e como confirmar cada uma.',
      ],
      testes: [
        'Qual a principal causa de delaminação?',
        'O que fazer ao ver layer shift sempre na mesma altura?',
      ],
      desafio:
        'Você recebe 6 peças defeituosas (uma de cada categoria: stringing, warping, delaminação, subextrusão, layer shift e z banding). Para cada uma, escreva o diagnóstico completo no formato Sintoma → Causa → Diagnóstico → Solução, e a ordem de ações que tomaria.',
      perguntas: [
        {
          pergunta: 'A peça delamina e também aparece warping. Trato os dois juntos?',
          resposta:
            'Sim, muitas vezes têm causa comum: cooling alto e/ou temperatura baixa em materiais que contraem (ABS/ASA). Feche a câmara, reduza o fan e ajuste a temperatura. Para o warping, reforce a adesão (brim/raft, mesa limpa). Atacar o ambiente térmico resolve ambos.',
        },
        {
          pergunta: 'Layer shift sempre na mesma altura — o que isso indica?',
          resposta:
            'Quase sempre uma colisão: o bico bate em uma parte mais alta da peça (over-extrusão/blob daquela camada) ou em um suporte. Verifique também correia e corrente do motor, mas a repetição na mesma altura aponta para obstáculo físico naquele ponto.',
        },
      ],
    },
  ],
}
