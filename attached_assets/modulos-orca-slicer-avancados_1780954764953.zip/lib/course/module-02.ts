import type { Modulo } from '@/lib/types'

export const modulo02: Modulo = {
  slug: 'impressora',
  numero: 2,
  titulo: 'Configurações da Impressora',
  subtitulo: 'O perfil que descreve sua máquina',
  descricao:
    'Volume de impressão, firmware, aceleração, jerk, limites da máquina, extrusor, bico, fluxo e temperaturas. Configurar errado aqui invalida todo o resto.',
  licoes: [
    {
      slug: 'volume-firmware-limites',
      titulo: 'Volume, Firmware e Limites da Máquina',
      resumo:
        'Altura máxima, volume de impressão, firmware, aceleração, jerk e limites cinemáticos.',
      duracao: '16 min',
      nivel: 'Intermediário',
      intro: [
        'O perfil de impressora informa ao OrcaSlicer os limites físicos e cinemáticos da sua máquina. Se esses valores estiverem errados, o slicer pode gerar G-code que sua impressora não consegue executar — ou que a danifica.',
        'É a fundação invisível: parâmetros de velocidade e aceleração no perfil de processo nunca poderão superar os limites definidos aqui.',
      ],
      secoes: [
        {
          titulo: 'Volume e altura máxima',
          conteudo: [
            'Bed shape e tamanho definem a área útil; a altura máxima (Z) define o quão alto você pode imprimir.',
            'Definir um volume maior que o real faz o slicer permitir peças que colidirão com a estrutura — sempre use as medidas reais do fabricante.',
            'Áreas de exclusão podem ser configuradas para acomodar clipes da mesa ou regiões irregulares.',
          ],
        },
        {
          titulo: 'Firmware (G-code flavor)',
          conteudo: [
            'Define o "dialeto" de G-code: Marlin, Klipper, RepRap, etc. Klipper aceita comandos como SET_VELOCITY_LIMIT; Marlin usa M201/M203/M204/M205.',
            'Escolher o flavor errado gera comandos que a placa ignora ou interpreta mal.',
          ],
        },
        {
          titulo: 'Aceleração, Jerk e limites da máquina',
          conteudo: [
            'Aceleração (mm/s²) controla quão rápido a impressora muda de velocidade. Alta aceleração reduz tempo mas pode gerar ringing (ghosting).',
            'Jerk (Marlin) / Square Corner Velocity (Klipper) é a mudança instantânea de velocidade permitida em cantos. Alto = cantos rápidos porém com mais vibração.',
            'Os limites da máquina (max speed/accel por eixo) são tetos de segurança — o slicer nunca os ultrapassa, independente do perfil de processo.',
          ],
        },
      ],
      estrutura: {
        oQueFaz:
          'Descreve as capacidades e limites físicos/cinemáticos da impressora.',
        comoFunciona:
          'O slicer emite comandos de limite (M201/M203/M204/M205 no Marlin) no início do G-code e nunca gera movimentos acima desses tetos.',
        quandoUsar:
          'Configure uma vez ao adicionar a impressora; revise se trocar firmware ou fizer upgrades mecânicos.',
        quandoEvitar:
          'Não aumente limites além do que o hardware aguenta só para "ir mais rápido" — causa perda de passos e falhas.',
        impactoResistencia:
          'Indireto: vibração excessiva por aceleração/jerk altos piora a adesão entre linhas e a precisão dimensional.',
        impactoQualidade:
          'Aceleração e jerk altos causam ringing/ghosting (ecos nas paredes). Valores calibrados (com Input Shaper) permitem velocidade alta sem artefatos.',
        impactoTempo:
          'Aceleração é frequentemente o maior gargalo de tempo em peças pequenas e detalhadas — mais que a velocidade máxima.',
        errosComuns: [
          'Definir volume maior que o real e colidir o bico com a estrutura.',
          'Selecionar firmware errado e a impressora ignorar limites.',
          'Subir aceleração sem calibrar Input Shaper, gerando ghosting.',
        ],
        comoCorrigir: [
          'Use as especificações oficiais do fabricante para volume e limites.',
          'Confirme o firmware real da placa antes de selecionar o flavor.',
          'Calibre Input Shaper (Módulo 5) antes de aumentar aceleração.',
        ],
        casosReais: [
          'Em uma máquina CoreXY com Klipper e Input Shaper calibrado, é possível subir a aceleração para 8000–12000 mm/s² mantendo qualidade — algo impossível numa cartesiana sem compensação.',
        ],
      },
      tabelas: [
        {
          titulo: 'Aceleração vs. resultado (orientativo)',
          colunas: ['Aceleração', 'Tempo', 'Ghosting', 'Quando usar'],
          linhas: [
            ['Baixa (500–1500)', 'Maior', 'Mínimo', 'Peças de alta qualidade visual'],
            ['Média (2000–4000)', 'Equilibrado', 'Leve', 'Uso geral'],
            ['Alta (5000+)', 'Menor', 'Alto sem IS', 'Protótipos rápidos / com Input Shaper'],
          ],
        },
      ],
      exercicios: [
        'Localize o volume real da sua impressora no site do fabricante e confira se o perfil bate.',
        'Identifique seu firmware (Marlin/Klipper) e confirme o G-code flavor selecionado.',
      ],
      testes: [
        'Qual a diferença entre velocidade máxima e aceleração no tempo de impressão?',
        'O que é jerk / square corner velocity?',
      ],
      desafio:
        'Sem calibrar nada ainda, defina um conjunto conservador e seguro de limites de máquina para sua impressora e justifique cada valor. Depois compare com os defaults do perfil.',
    },
    {
      slug: 'extrusor-bico-fluxo-temperatura',
      titulo: 'Extrusor, Bico, Fluxo e Temperaturas',
      resumo:
        'Diâmetro do bico, fluxo volumétrico máximo, calibração de fluxo e temperaturas base.',
      duracao: '14 min',
      nivel: 'Intermediário',
      intro: [
        'O extrusor e o bico definem quanto e quão rápido você consegue depositar plástico. O diâmetro do bico é a variável mais subestimada: ele muda quase tudo.',
        'Fluxo volumétrico máximo é o teto real de velocidade — não adianta pedir 300 mm/s se o hotend só derrete 12 mm³/s.',
      ],
      secoes: [
        {
          titulo: 'Diâmetro do bico',
          conteudo: [
            '0,4 mm é o padrão equilibrado. Bicos maiores (0,6–0,8 mm) imprimem muito mais rápido e mais forte, mas com menos detalhe. Bicos menores (0,2–0,25 mm) dão detalhe fino e impressões lentas.',
            'O diâmetro define a largura de extrusão padrão e limita a espessura de camada útil (regra geral: layer height entre 25% e 75% do diâmetro do bico).',
          ],
        },
        {
          titulo: 'Fluxo volumétrico máximo',
          conteudo: [
            'Medido em mm³/s, é quanto plástico o hotend consegue fundir por segundo. É o limite real que casa velocidade × largura × altura de camada.',
            'Hotends comuns: 8–15 mm³/s; high-flow (Volcano, CHT): 20–40+ mm³/s.',
            'O slicer reduz automaticamente a velocidade para não ultrapassar esse limite — por isso peças finas "não atingem" a velocidade configurada.',
          ],
        },
        {
          titulo: 'Fluxo (flow ratio) e temperaturas',
          conteudo: [
            'Flow ratio corrige sobre/subextrusão. Calibra-se com o teste de Flow (Módulo 5).',
            'As temperaturas base (bico e mesa) vivem no perfil de filamento, mas o extrusor define limites e o offset de temperatura.',
          ],
        },
      ],
      estrutura: {
        oQueFaz:
          'Define a capacidade de deposição: diâmetro, vazão máxima e correção de fluxo.',
        comoFunciona:
          'O volume extrudado por segundo = velocidade × largura da linha × altura da camada. O slicer respeita o teto de mm³/s reduzindo a velocidade quando necessário.',
        quandoUsar:
          'Configure o diâmetro do bico real e meça o fluxo volumétrico máximo via teste antes de buscar velocidade.',
        quandoEvitar:
          'Não configure um diâmetro de bico diferente do físico — gera sub/superextrusão sistemática.',
        impactoResistencia:
          'Bico maior e linhas mais largas aumentam significativamente a resistência (menos interfaces entre linhas).',
        impactoQualidade:
          'Bico menor = mais detalhe; bico maior = perde detalhe fino mas ganha velocidade.',
        impactoTempo:
          'Fluxo volumétrico é o teto absoluto de velocidade. Bico 0,6 mm pode cortar o tempo pela metade vs 0,4 mm.',
        impactoFilamento:
          'Bicos maiores depositam mais por passada; o consumo total de material é similar, mas o tempo cai muito.',
        errosComuns: [
          'Configurar bico 0,4 com bico físico 0,6 instalado (ou vice-versa).',
          'Pedir velocidades altas que o hotend não sustenta e estranhar a subextrusão.',
        ],
        comoCorrigir: [
          'Confirme fisicamente o bico instalado.',
          'Rode o teste de Maximum Flow (Módulo 5) e configure o limite real.',
        ],
        casosReais: [
          'Para peças funcionais grandes (suportes, ferramentas), um bico 0,6 mm com 3 paredes resulta mais forte e mais rápido que 0,4 mm com 4 paredes.',
        ],
      },
      tabelas: [
        {
          titulo: 'Diâmetro do bico — trade-offs',
          colunas: ['Bico', 'Detalhe', 'Velocidade', 'Resistência', 'Uso típico'],
          linhas: [
            ['0,2–0,25 mm', 'Altíssimo', 'Lenta', 'Baixa', 'Miniaturas, joias'],
            ['0,4 mm', 'Bom', 'Média', 'Boa', 'Uso geral'],
            ['0,6 mm', 'Médio', 'Rápida', 'Alta', 'Peças funcionais'],
            ['0,8 mm', 'Baixo', 'Muito rápida', 'Muito alta', 'Grandes/estruturais'],
          ],
        },
      ],
      exercicios: [
        'Calcule o fluxo necessário para 200 mm/s, linha 0,42 mm e camada 0,2 mm (V = vel × largura × altura).',
        'Compare a mesma peça fatiada com bico 0,4 e 0,6 mm: anote tempo e número de paredes.',
      ],
      testes: [
        'Por que peças finas não atingem a velocidade máxima configurada?',
        'Qual a regra geral para layer height em função do diâmetro do bico?',
      ],
      desafio:
        'Você precisa produzir 500 suportes de parede por mês com máxima resistência e menor tempo. Escolha o diâmetro de bico ideal e justifique considerando fluxo, resistência e tempo.',
      perguntas: [
        {
          pergunta:
            'Aumentei a velocidade mas o tempo quase não mudou. Por quê?',
          resposta:
            'Provavelmente você atingiu o teto de fluxo volumétrico do hotend. O slicer está limitando a velocidade real para não subextrudir. Aumente o fluxo (hotend high-flow / bico maior) ou aceite o teto.',
        },
      ],
    },
  ],
}
