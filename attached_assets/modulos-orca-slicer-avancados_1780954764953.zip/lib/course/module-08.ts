import type { Modulo } from '@/lib/types'

export const modulo08: Modulo = {
  slug: 'estudos-de-caso',
  numero: 8,
  titulo: 'Estudos de Caso',
  subtitulo: 'A configuração ideal para cada tipo de peça',
  descricao:
    'Análise prática de peças reais: suportes, vasos, organizadores, peças automotivas, dobradiças, engrenagens, brinquedos, decoração e produtos para venda. Para cada uma: orientação, material, infill, camada, velocidade e custo-benefício.',
  licoes: [
    {
      slug: 'funcionais-mecanicas',
      titulo: 'Peças Funcionais: Suportes, Dobradiças, Engrenagens e Automotivas',
      resumo:
        'Como configurar peças que precisam aguentar carga, movimento e calor.',
      duracao: '20 min',
      nivel: 'Especialista',
      intro: [
        'Peças funcionais perdoam pouco: erro de orientação ou material as faz falhar em uso. Aqui o critério é resistência e durabilidade, não aparência.',
      ],
      secoes: [
        {
          titulo: 'Suporte de ferramentas e organizadores',
          conteudo: [
            'Orientação: base maior na mesa para estabilidade; cargas ao longo das camadas.',
            'Material: PETG (tenaz) ou PLA para uso interno leve.',
            'Infill 15–25% gyroid, 3–4 paredes, camada 0,2–0,28 mm. Foco em custo-benefício e velocidade.',
          ],
        },
        {
          titulo: 'Dobradiças e engrenagens',
          conteudo: [
            'Dobradiça: oriente o eixo do movimento ao longo das camadas para não delaminar; tolerance test é obrigatório para o encaixe.',
            'Engrenagem: dentes precisam de boa adesão; oriente plana, camada fina (0,12–0,16 mm) para dentes precisos; material PETG/Nylon para desgaste; mais paredes.',
          ],
        },
        {
          titulo: 'Peças automotivas',
          conteudo: [
            'Calor é o inimigo: nunca PLA. ASA (sol/externo) ou PC/Nylon-CF (sob o capô).',
            'Máxima resistência: 4–6 paredes, infill 30–40%, orientação alinhada às cargas, câmara fechada.',
          ],
        },
      ],
      estrutura: {
        quandoUsar:
          'Sempre que a peça tiver função mecânica, suportar carga, movimento ou calor.',
        impactoResistencia:
          'Material + orientação + paredes são as decisões dominantes.',
        impactoQualidade:
          'Secundária; foco em precisão de encaixe (tolerance).',
        casosReais: [
          'Uma engrenagem em PLA derrete por atrito; em Nylon-CF dura muito mais.',
        ],
      },
      tabelas: [
        {
          titulo: 'Receitas para peças funcionais',
          colunas: ['Peça', 'Material', 'Infill', 'Paredes', 'Camada'],
          linhas: [
            ['Suporte de ferramenta', 'PETG', '15–20% gyroid', '3–4', '0,2–0,28'],
            ['Dobradiça', 'PETG', '20%', '4', '0,16–0,2'],
            ['Engrenagem', 'Nylon/PETG', '30–40%', '4–5', '0,12–0,16'],
            ['Peça automotiva', 'ASA/PC-CF', '30–40%', '5–6', '0,16–0,2'],
          ],
        },
      ],
      exercicios: [
        'Configure uma engrenagem e justifique cada parâmetro.',
        'Escolha material e orientação para um suporte que segura 5 kg na parede.',
      ],
      testes: [
        'Por que PLA é proibido em peças automotivas expostas ao calor?',
        'Por que dobradiças exigem tolerance test?',
      ],
      desafio:
        'Projete o perfil completo de uma engrenagem que opera com atrito contínuo a 60 °C. Material, orientação, camada, paredes, infill — tudo justificado.',
    },
    {
      slug: 'esteticas-comerciais',
      titulo: 'Peças Estéticas e Comerciais: Vasos, Brinquedos, Decoração e Produtos',
      resumo:
        'Quando a aparência e o custo de produção mandam mais que a resistência.',
      duracao: '18 min',
      nivel: 'Avançado',
      intro: [
        'Em peças estéticas e produtos para venda, o equilíbrio muda: acabamento e custo por unidade dominam. Aqui você vende a aparência e a margem.',
      ],
      secoes: [
        {
          titulo: 'Vasos (modo espiral / vase mode)',
          conteudo: [
            'Spiralize outer contour: imprime parede única contínua, sem costura e muito rápido.',
            'Camada um pouco mais grossa e largura de linha maior dão paredes mais fortes em vaso.',
            'Material: PLA/PETG; 0% infill por definição.',
          ],
        },
        {
          titulo: 'Brinquedos e decoração',
          conteudo: [
            'Brinquedos: PLA seguro e colorido; paredes suficientes para aguentar quedas (3+), infill 15%.',
            'Decoração: foco no acabamento — outer wall lenta, variable layer height nas áreas de detalhe, monotonic no topo.',
          ],
        },
        {
          titulo: 'Produtos para venda',
          conteudo: [
            'Minimize tempo e material por unidade sem comprometer o que o cliente percebe.',
            'Padronize um perfil comercial: 0,2 mm, 15% gyroid, 3 paredes, outer wall lenta, suporte mínimo.',
            'Acabamento consistente entre lotes é mais importante que perfeição absoluta.',
          ],
        },
      ],
      estrutura: {
        quandoUsar:
          'Peças onde aparência e custo unitário superam a exigência mecânica.',
        impactoQualidade:
          'Dominante: outer wall, top surface e orientação definem a percepção de valor.',
        impactoFilamento:
          'Custo por unidade é o que define a margem — otimize infill e suporte.',
        casosReais: [
          'Um vaso em vase mode usa pouco material, imprime rápido e tem acabamento contínuo sem costura — produto ideal para venda.',
        ],
      },
      tabelas: [
        {
          titulo: 'Receitas para peças estéticas/comerciais',
          colunas: ['Peça', 'Material', 'Infill', 'Destaque'],
          linhas: [
            ['Vaso', 'PLA/PETG', '0% (vase mode)', 'Parede única, sem costura'],
            ['Brinquedo', 'PLA', '15%', '3+ paredes (queda)'],
            ['Decoração', 'PLA', '10–15%', 'Outer wall lenta + variable layer'],
            ['Produto à venda', 'PLA/PETG', '15% gyroid', 'Perfil padronizado'],
          ],
        },
      ],
      exercicios: [
        'Imprima um vaso em vase mode e em modo normal e compare tempo e material.',
        'Crie um "perfil comercial" reutilizável e documente-o.',
      ],
      testes: [
        'Por que vase mode é tão econômico?',
        'O que mais importa num produto para venda: perfeição ou consistência entre lotes?',
      ],
      desafio:
        'Crie o perfil comercial ideal para vender 100 vasos/mês com a melhor relação aparência × custo × tempo. Justifique cada escolha.',
    },
  ],
}
