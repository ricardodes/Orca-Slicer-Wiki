import type { Modulo } from '@/lib/types'

export const modulo09: Modulo = {
  slug: 'comercial',
  numero: 9,
  titulo: 'Impressão 3D Comercial',
  subtitulo: 'Transforme conhecimento técnico em lucro',
  descricao:
    'Como calcular custo real e lucro, reduzir desperdício e criar perfis comerciais padronizados. A parte que separa hobby de negócio.',
  licoes: [
    {
      slug: 'custo-lucro-perfis',
      titulo: 'Custo, Lucro e Perfis Comerciais',
      resumo:
        'A fórmula completa de precificação e como padronizar a produção.',
      duracao: '18 min',
      nivel: 'Especialista',
      intro: [
        'Quem não calcula custo real trabalha de graça (ou no prejuízo). O preço de uma peça vai muito além do peso do filamento.',
        'O custo total inclui material, energia, depreciação da máquina, taxa de falha, pós-processamento e o seu tempo.',
      ],
      secoes: [
        {
          titulo: 'Calculando o custo real',
          conteudo: [
            'Material: (gramas usadas ÷ 1000) × preço do kg. Inclua o suporte e o purge.',
            'Energia: potência média (kW) × horas × tarifa kWh.',
            'Depreciação: preço da máquina ÷ vida útil estimada (horas) × horas da peça.',
            'Manutenção e consumíveis: bicos, correias, placa — rateie por hora.',
            'Taxa de falha: adicione uma % (ex.: 5–10%) para cobrir reimpressões.',
            'Mão de obra: tempo de setup, remoção de suporte, acabamento × seu valor/hora.',
          ],
        },
        {
          titulo: 'Calculando o lucro',
          conteudo: [
            'Preço de venda = custo total × margem desejada (ex.: 2x a 4x para varejo).',
            'Considere o valor percebido, não só o custo — peças exclusivas vendem por mais.',
            'Lucro = preço de venda − custo total. Acompanhe a margem por produto.',
          ],
        },
        {
          titulo: 'Perfis comerciais e redução de desperdício',
          conteudo: [
            'Crie perfis padronizados por categoria (decorativo, funcional, premium) para garantir consistência e previsibilidade de custo.',
            'Reduza desperdício: minimize suporte, otimize orientação, agrupe peças por placa, calibre para reduzir falhas.',
            'Documente cada perfil com tempo e material esperados — isso vira sua tabela de preços.',
          ],
        },
      ],
      estrutura: {
        oQueFaz:
          'Converte parâmetros técnicos em decisões financeiras lucrativas.',
        comoFunciona:
          'Cada hora de máquina e grama de material tem custo; o preço cobre custo + margem + valor percebido.',
        quandoUsar:
          'Em qualquer venda; perfis padronizados em produção recorrente.',
        impactoFilamento:
          'Material é custo direto: cada grama de suporte evitado é margem.',
        impactoTempo:
          'Tempo de máquina e de mão de obra são os maiores custos ocultos.',
        errosComuns: [
          'Precificar só pelo peso do filamento (ignora energia, falha, mão de obra).',
          'Não incluir taxa de falha e quebrar a margem na primeira reimpressão.',
        ],
        comoCorrigir: [
          'Use a fórmula completa de custo.',
          'Adicione 5–10% de taxa de falha e cobre seu tempo.',
        ],
        casosReais: [
          'Um vendedor cobrava só o filamento e tinha "prejuízo invisível"; ao incluir energia, depreciação e tempo, descobriu que precisava dobrar o preço.',
        ],
      },
      tabelas: [
        {
          titulo: 'Composição do custo de uma peça',
          colunas: ['Item', 'Como calcular', 'Peso típico'],
          linhas: [
            ['Material', 'g × preço/kg', 'Médio'],
            ['Energia', 'kW × h × tarifa', 'Baixo'],
            ['Depreciação', 'preço máquina ÷ vida útil × h', 'Médio'],
            ['Falha', '% sobre o custo', 'Variável'],
            ['Mão de obra', 'tempo × valor/hora', 'Alto'],
          ],
        },
      ],
      exercicios: [
        'Calcule o custo total real de uma peça que você já imprimiu, incluindo todos os itens.',
        'Defina margens para 3 categorias de produto e monte uma mini tabela de preços.',
      ],
      testes: [
        'Quais custos as pessoas mais esquecem ao precificar?',
        'Por que incluir uma taxa de falha?',
      ],
      desafio:
        'Monte a planilha de precificação completa de um produto seu, do custo ao preço final com margem, e justifique a margem escolhida frente ao valor percebido.',
    },
  ],
}
