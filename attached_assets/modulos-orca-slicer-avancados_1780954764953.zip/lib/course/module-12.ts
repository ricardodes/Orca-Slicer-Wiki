import type { Modulo } from '@/lib/types'

export const modulo12: Modulo = {
  slug: 'velocidade-input-shaper',
  numero: 12,
  titulo: 'Velocidade Extrema e Input Shaper',
  subtitulo: 'Imprima até 70% mais rápido',
  descricao:
    'Entenda o que realmente limita a velocidade, calibre aceleração, jerk e Input Shaper, e respeite os limites de fluxo do hotend para imprimir rápido sem destruir a qualidade.',
  licoes: [
    {
      slug: 'o-que-limita-velocidade',
      titulo: 'O que realmente limita a velocidade',
      resumo:
        'Hotend, extrusor, mecânica e os trade-offs entre velocidade, qualidade e resistência.',
      duracao: '20 min',
      nivel: 'Avançado',
      intro: [
        'Aumentar o número de velocidade no slicer não faz a peça sair mais rápido se outro componente for o gargalo.',
        'A velocidade real é limitada pelo elo mais fraco: capacidade de fundir filamento (hotend), de empurrar (extrusor) e de mover sem vibrar (mecânica).',
      ],
      secoes: [
        {
          titulo: 'Os três limites físicos',
          conteudo: [
            'Limite do Hotend: quantidade de material que ele consegue fundir por segundo (Maximum Volumetric Flow). Se você anda rápido demais, o filamento sai frio e subextrudido.',
            'Limite do Extrusor: força e tração para empurrar o filamento sem patinar.',
            'Limite da Máquina: rigidez do frame, massa do conjunto móvel e qualidade dos motores definem quanta aceleração é possível sem vibrar.',
          ],
        },
        {
          titulo: 'Os trade-offs',
          conteudo: [
            'Speed vs Quality: mais velocidade = mais vibração e menos tempo de resfriamento = mais defeitos visuais.',
            'Speed vs Strength: camadas depositadas rápido aderem pior entre si; a resistência entre camadas pode cair.',
            'A estratégia profissional é acelerar onde não importa (infill, paredes internas) e ir devagar onde importa (parede externa, pontes, primeira camada).',
          ],
        },
      ],
      tabelas: [
        {
          titulo: 'Onde acelerar e onde frear',
          colunas: ['Região', 'Estratégia', 'Motivo'],
          linhas: [
            ['Infill', 'Rápido', 'Não é visível nem crítico'],
            ['Parede interna', 'Rápido', 'Coberta pela externa'],
            ['Parede externa', 'Lento', 'Define o acabamento'],
            ['Primeira camada', 'Lento', 'Adesão à mesa'],
            ['Pontes (bridges)', 'Médio/lento', 'Precisa resfriar'],
          ],
        },
      ],
      estrutura: {
        oQueFaz:
          'Identifica o gargalo real para que o aumento de velocidade seja efetivo.',
        impactoTempo: 'Direto — atacar o gargalo certo reduz o tempo real.',
        impactoQualidade: 'Acelerar o elo errado degrada a peça sem ganhar tempo.',
      },
      exercicios: [
        'Identifique qual é o gargalo da sua impressora: hotend, extrusor ou mecânica.',
        'Liste 3 regiões da sua última peça que poderiam ser aceleradas sem prejuízo.',
      ],
      testes: [
        'O que é o gargalo de velocidade e por que importa?',
        'Por que acelerar o infill é mais seguro que acelerar a parede externa?',
      ],
    },
    {
      slug: 'aceleracao-jerk',
      titulo: 'Aceleração, Jerk e os limites de movimento',
      resumo:
        'Como aceleração e jerk afetam tempo real, ringing e qualidade.',
      duracao: '20 min',
      nivel: 'Avançado',
      intro: [
        'A velocidade máxima quase nunca é atingida em peças com detalhes: o que define o tempo real é a aceleração.',
        'Aceleração é a rapidez com que a impressora muda de velocidade; jerk é a mudança instantânea de velocidade permitida em uma esquina.',
      ],
      secoes: [
        {
          titulo: 'Aceleração',
          conteudo: [
            'Em trajetos curtos (peças detalhadas), a impressora acelera e freia o tempo todo e nunca chega à velocidade máxima.',
            'Aumentar a aceleração reduz o tempo real mais que aumentar a velocidade nominal.',
            'Aceleração alta demais gera vibração (ringing) e perda de passos.',
          ],
        },
        {
          titulo: 'Jerk (Junction Deviation)',
          conteudo: [
            'O jerk define quão bruscamente a máquina pode mudar de direção sem desacelerar totalmente.',
            'Jerk baixo = cantos mais arredondados e impressão mais lenta; jerk alto = cantos mais nítidos, porém mais vibração.',
            'Em firmwares modernos, "Junction Deviation" substitui o jerk clássico com transições mais suaves.',
          ],
        },
      ],
      estrutura: {
        comoFunciona:
          'O perfil de movimento (velocidade, aceleração, jerk) determina quanto tempo a máquina passa de fato em alta velocidade.',
        errosComuns: [
          'Subir só a velocidade e esquecer a aceleração.',
          'Aceleração alta sem Input Shaper, gerando ghosting.',
        ],
        comoCorrigir: [
          'Aumente a aceleração gradualmente e observe o ringing.',
          'Calibre Input Shaper antes de subir a aceleração.',
        ],
      },
      exercicios: [
        'Imprima um cubo de calibração com aceleração baixa e alta e compare os cantos.',
        'Anote o tempo de fatiamento ao dobrar a aceleração mantendo a velocidade.',
      ],
      testes: [
        'Por que aceleração impacta mais o tempo real que a velocidade nominal em peças pequenas?',
        'O que é jerk e como afeta os cantos?',
      ],
    },
    {
      slug: 'input-shaper-ressonancia',
      titulo: 'Input Shaper, Resonance Compensation e VFA',
      resumo:
        'A tecnologia que permite alta aceleração sem ghosting e ringing.',
      duracao: '24 min',
      nivel: 'Especialista',
      intro: [
        'Input Shaper (também chamado Resonance Compensation) é o que torna possível imprimir rápido com qualidade nas impressoras modernas.',
        'Toda estrutura tem frequências de ressonância. Quando a impressora muda de direção, ela "toca" essa frequência e a peça vibra — gerando defeitos.',
      ],
      secoes: [
        {
          titulo: 'O que é Input Shaper',
          conteudo: [
            'É um algoritmo que antecipa e cancela as vibrações da estrutura, ajustando os movimentos para não excitar as frequências de ressonância.',
            'Com ele ativo e calibrado, você pode usar aceleração muito mais alta sem ghosting.',
            'A calibração mede as frequências (X e Y) com um acelerômetro ou via padrões de teste impressos.',
          ],
        },
        {
          titulo: 'Ghosting, Ringing e VFA',
          conteudo: [
            'Ghosting / Ringing: ecos e sombras que aparecem depois de cada quina, causados pela vibração após a mudança de direção.',
            'VFA (Vertical Fine Artifacts): listras verticais finas e regulares, geralmente ligadas a frequência de passo dos motores e correias.',
            'Input Shaper resolve o ghosting; o VFA muitas vezes exige ajustes de velocidade específicos, qualidade de correia e microstepping.',
          ],
        },
      ],
      tabelas: [
        {
          titulo: 'Defeito de vibração x causa x solução',
          colunas: ['Defeito', 'Aparência', 'Causa', 'Solução'],
          linhas: [
            ['Ghosting/Ringing', 'Ecos após quinas', 'Aceleração alta sem IS', 'Calibrar Input Shaper'],
            ['VFA', 'Listras verticais finas', 'Ressonância de motor/correia', 'Ajustar velocidade, correias'],
            ['Layer shift', 'Camadas deslocadas', 'Perda de passos', 'Reduzir aceleração/corrente'],
          ],
        },
      ],
      estrutura: {
        oQueFaz:
          'Cancela vibrações para permitir alta aceleração sem perda de qualidade.',
        comoFunciona:
          'Mede as frequências de ressonância dos eixos e modela os comandos de movimento para não excitá-las.',
        quandoUsar:
          'Sempre que quiser velocidade alta com bom acabamento. É pré-requisito para impressão rápida.',
        impactoQualidade: 'Elimina ghosting mesmo em alta aceleração.',
      },
      exercicios: [
        'Rode a calibração de Input Shaper da sua impressora e anote as frequências de X e Y.',
        'Imprima o teste de ringing antes e depois e compare os ecos.',
      ],
      testes: [
        'Qual defeito o Input Shaper corrige?',
        'Qual a diferença entre ghosting e VFA?',
      ],
    },
    {
      slug: 'fluxo-volumetrico-limites',
      titulo: 'Maximum Volumetric Flow e os limites do hotend',
      resumo:
        'O teto real de velocidade: quanto material seu hotend consegue fundir.',
      duracao: '22 min',
      nivel: 'Especialista',
      intro: [
        'Por mais rápido que a mecânica permita, se o hotend não funde material suficiente, a peça sai subextrudida.',
        'O Maximum Volumetric Flow (MVF), em mm³/s, é o teto absoluto de velocidade de qualquer perfil.',
      ],
      secoes: [
        {
          titulo: 'Entendendo o MVF',
          conteudo: [
            'MVF = altura de camada × largura de extrusão × velocidade. O OrcaSlicer limita automaticamente a velocidade para não ultrapassar o MVF configurado.',
            'Hotends comuns: ~10–15 mm³/s. Hotends de alto fluxo (volcano, CHT): 20–40 mm³/s.',
            'Calibre o MVF real com o teste de Flow do OrcaSlicer, aumentando o fluxo até aparecer subextrusão.',
          ],
        },
        {
          titulo: 'Estratégias para fluxo maior',
          conteudo: [
            'Bico maior (0,6 / 0,8 mm) deposita mais material por passada — ganho enorme de velocidade real.',
            'Altura de camada maior também aumenta o fluxo por mm percorrido.',
            'Hotend de alto fluxo e temperatura levemente mais alta aumentam o MVF — sempre dentro da faixa do filamento.',
          ],
        },
      ],
      tabelas: [
        {
          titulo: 'MVF típico por configuração',
          colunas: ['Configuração', 'MVF aproximado', 'Observação'],
          linhas: [
            ['Hotend padrão 0,4 mm', '~10–12 mm³/s', 'Limite comum'],
            ['Hotend alto fluxo 0,4 mm', '~20–25 mm³/s', 'Volcano/CHT'],
            ['Bico 0,6 mm alto fluxo', '~25–30 mm³/s', 'Ótimo p/ produção'],
            ['Bico 0,8 mm alto fluxo', '~30–40 mm³/s', 'Peças grandes rápidas'],
          ],
        },
      ],
      estrutura: {
        oQueFaz:
          'Define o teto absoluto de velocidade conforme a capacidade de fusão do hotend.',
        impactoTempo: 'Aumentar o MVF (bico/altura/hotend) é o caminho mais eficaz para velocidade real.',
        errosComuns: [
          'Subir a velocidade ignorando o MVF e obter subextrusão.',
          'Não calibrar o MVF e confiar no valor padrão.',
        ],
        comoCorrigir: [
          'Rode o teste de flow máximo do OrcaSlicer.',
          'Use bico maior e/ou altura de camada maior para ganhos reais.',
        ],
      },
      exercicios: [
        'Calibre o MVF real do seu hotend com o teste do OrcaSlicer.',
        'Recalcule a velocidade máxima possível para uma camada de 0,2 mm e largura 0,45 mm.',
      ],
      testes: [
        'O que é Maximum Volumetric Flow e como ele limita a velocidade?',
        'Por que um bico maior aumenta a velocidade real mais que apenas subir a velocidade no slicer?',
      ],
      desafio:
        'Pegue um perfil padrão de 15 mm³/s e reduza o tempo de uma peça em pelo menos 50% combinando: Input Shaper calibrado, aceleração mais alta, bico maior, camada mais alta e MVF calibrado — sem que apareça ghosting ou subextrusão. Documente cada decisão e o tempo antes/depois.',
      perguntas: [
        {
          pergunta: 'Aumentei a velocidade mas a peça ficou com falhas e mais fina. O que aconteceu?',
          resposta:
            'Você provavelmente ultrapassou o Maximum Volumetric Flow do hotend: ele não conseguiu fundir material suficiente e ocorreu subextrusão. Reduza a velocidade até o MVF, ou aumente a capacidade de fluxo (bico maior, hotend de alto fluxo, temperatura).',
        },
        {
          pergunta: 'Quero velocidade sem ghosting. Por onde começo?',
          resposta:
            'Calibre o Input Shaper primeiro. Só depois aumente a aceleração. Em seguida, eleve o MVF com bico/altura maiores. Mantenha a parede externa lenta para preservar o acabamento.',
        },
      ],
    },
  ],
}
