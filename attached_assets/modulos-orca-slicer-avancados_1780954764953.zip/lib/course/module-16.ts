import type { Modulo } from '@/lib/types'

export const modulo16: Modulo = {
  slug: 'estudos-de-caso-avancados',
  numero: 16,
  titulo: 'Estudos de Caso Reais',
  subtitulo: 'Decisões corretas para qualquer peça',
  descricao:
    'Dez estudos completos — do vaso decorativo ao produto viral — com material, parâmetros, custo, lucro estimado e justificativa técnica de cada decisão.',
  licoes: [
    {
      slug: 'casos-decorativos',
      titulo: 'Casos decorativos e organizadores',
      resumo:
        'Vaso decorativo, organizador e suporte de ferramentas: estética e funcionalidade leve.',
      duracao: '24 min',
      nivel: 'Especialista',
      intro: [
        'Estes produtos vendem pela aparência e pela utilidade no dia a dia. As decisões priorizam acabamento e baixo custo de material.',
        'Cada caso segue o método: material → camada → paredes → infill → suporte → velocidade → custo → lucro → justificativa.',
      ],
      secoes: [
        {
          titulo: 'Caso 1 — Vaso decorativo',
          conteudo: [
            'Material: PLA (Silk para brilho) ou PETG se for para água/planta real.',
            'Layer Height: 0,2 mm; Walls: modo vaso (spiral/vase) com 1 parede, ou 2–3 paredes.',
            'Infill: 0% (vaso é oco); Support: nenhum.',
            'Velocidade: parede externa lenta para superfície lisa; Seam: Random.',
            'Custo baixo (pouco material), lucro alto pela percepção decorativa. Justificativa: estética manda, resistência é secundária.',
          ],
        },
        {
          titulo: 'Caso 2 — Organizador',
          conteudo: [
            'Material: PLA ou PETG; Layer Height: 0,24–0,28 mm (rápido).',
            'Walls: 2–3; Infill: 10–15% gyroid; Support: nenhum (projetar sem balanços).',
            'Velocidade: alta; Seam: Aligned numa quina.',
            'Custo moderado, margem boa em volume. Justificativa: funcional leve, prioriza tempo e custo.',
          ],
        },
        {
          titulo: 'Caso 3 — Suporte de ferramentas',
          conteudo: [
            'Material: PETG (resistência e tenacidade) ou PLA+ ; Layer: 0,24 mm.',
            'Walls: 3–4; Infill: 15–20%; Support: mínimo.',
            'Velocidade: média; reforçar paredes onde a ferramenta apoia.',
            'Justificativa: suporta peso e uso repetido, então paredes contam mais que infill.',
          ],
        },
      ],
      tabelas: [
        {
          titulo: 'Resumo — decorativos e organizadores',
          colunas: ['Produto', 'Material', 'Camada', 'Infill'],
          linhas: [
            ['Vaso', 'PLA Silk/PETG', '0,2 mm', '0% (oco)'],
            ['Organizador', 'PLA/PETG', '0,24–0,28 mm', '10–15%'],
            ['Suporte ferramentas', 'PETG/PLA+', '0,24 mm', '15–20%'],
          ],
        },
      ],
      estrutura: {
        oQueFaz: 'Mostra como decisões mudam conforme o produto prioriza estética ou função leve.',
        casosReais: [
          'Vaso em modo spiral: praticamente sem infill, custo mínimo e visual premium — campeão de margem.',
        ],
      },
      exercicios: [
        'Configure um vaso em modo spiral e calcule o custo de material.',
        'Defina o perfil de um organizador para produção rápida em lote.',
      ],
      testes: [
        'Por que um vaso usa 0% de infill?',
        'Por que o suporte de ferramentas prioriza paredes em vez de infill?',
      ],
    },
    {
      slug: 'casos-funcionais',
      titulo: 'Casos funcionais e mecânicos',
      resumo:
        'Dobradiça, engrenagem e peça automotiva: resistência e precisão.',
      duracao: '26 min',
      nivel: 'Especialista',
      intro: [
        'Aqui a função domina: a peça precisa aguentar carga, calor ou movimento. Material e orientação são as decisões mais críticas.',
      ],
      secoes: [
        {
          titulo: 'Caso 4 — Dobradiça',
          conteudo: [
            'Material: PETG ou PLA+ (toleram flexão); Layer: 0,16–0,2 mm.',
            'Walls: 3; Infill: 20%; Support: conforme o modelo (print-in-place evita).',
            'Orientação: articulação no plano XY para não delaminar; folga 0,3–0,4 mm.',
            'Justificativa: movimento repetido exige tenacidade e orientação correta.',
          ],
        },
        {
          titulo: 'Caso 5 — Engrenagem',
          conteudo: [
            'Material: PETG ou Nylon (desgaste) ; Layer: 0,12–0,16 mm para dentes definidos.',
            'Walls: 3–4; Infill: 25–40%; Support: nenhum.',
            'Backlash de 0,2 mm; parede externa lenta; eixo no Z.',
            'Justificativa: precisão de perfil e resistência ao desgaste mandam.',
          ],
        },
        {
          titulo: 'Caso 6 — Peça automotiva',
          conteudo: [
            'Material: ASA ou ABS (calor e UV do interior/motor); Layer: 0,2 mm.',
            'Walls: 4; Infill: 30–40%; Support: conforme geometria.',
            'Câmara fechada para evitar warping; orientar a carga ao longo das camadas.',
            'Justificativa: ambiente quente e exposto ao sol exige material resistente a temperatura e UV.',
          ],
        },
      ],
      tabelas: [
        {
          titulo: 'Resumo — funcionais e mecânicos',
          colunas: ['Produto', 'Material', 'Infill', 'Ponto crítico'],
          linhas: [
            ['Dobradiça', 'PETG/PLA+', '20%', 'Orientação XY'],
            ['Engrenagem', 'PETG/Nylon', '25–40%', 'Backlash 0,2 mm'],
            ['Peça automotiva', 'ASA/ABS', '30–40%', 'Calor e UV'],
          ],
        },
      ],
      estrutura: {
        oQueFaz: 'Aplica orientação e material à exigência mecânica/ambiental de cada peça.',
        impactoResistencia: 'Decisivo — material e orientação errados condenam a peça em uso.',
        casosReais: [
          'Suporte automotivo em PLA derreteu ao sol; refeito em ASA, resolveu definitivamente.',
        ],
      },
      exercicios: [
        'Justifique tecnicamente por que a peça automotiva usa ASA e não PLA.',
        'Defina backlash e orientação para uma engrenagem funcional.',
      ],
      testes: [
        'Por que uma peça automotiva exige ASA/ABS?',
        'Qual o ponto crítico de uma engrenagem impressa?',
      ],
    },
    {
      slug: 'casos-comerciais-virais',
      titulo: 'Casos comerciais e produtos virais',
      resumo:
        'Religioso, pet, brinquedo articulado e produto viral: margem e volume.',
      duracao: '26 min',
      nivel: 'Especialista',
      intro: [
        'Estes são os campeões de venda em marketplace. As decisões equilibram apelo visual, custo baixíssimo e velocidade de produção.',
      ],
      secoes: [
        {
          titulo: 'Caso 7 — Produto religioso',
          conteudo: [
            'Material: PLA (detalhe e cor) ou resina-look com PLA Silk; Layer: 0,12–0,16 mm para detalhes.',
            'Walls: 2–3; Infill: 10%; Support: conforme a estátua/relevo.',
            'Acabamento: parede externa lenta, Ironing em bases planas.',
            'Justificativa: detalhe e acabamento sustentam o valor emocional e o preço.',
          ],
        },
        {
          titulo: 'Caso 8 — Produto para pets',
          conteudo: [
            'Material: PETG (resistência e atóxico para mordidas leves); evitar peças que o pet possa engolir.',
            'Layer: 0,2 mm; Walls: 3–4; Infill: 20–30% (mordida/queda).',
            'Justificativa: durabilidade e segurança são prioridade; reforço por paredes.',
          ],
        },
        {
          titulo: 'Caso 9 — Brinquedo articulado',
          conteudo: [
            'Material: PLA; print-in-place (já montado) ; Layer: 0,16–0,2 mm.',
            'Walls: 2; Infill: 10–15%; Support: nenhum (modelado para não precisar).',
            'Folga das articulações 0,3 mm; Seam discreta. Justificativa: viral, barato e impresso já articulado = altíssima margem.',
          ],
        },
        {
          titulo: 'Caso 10 — Produto viral para marketplaces',
          conteudo: [
            'Material: PLA barato; Layer: 0,24–0,28 mm (velocidade); bico 0,6 mm.',
            'Walls: 2; Infill: 10%; Support: evitar por projeto.',
            'Placa cheia, perfil padronizado, embalagem com marca.',
            'Justificativa: tudo otimizado para custo mínimo, produção em lote e giro rápido.',
          ],
        },
      ],
      tabelas: [
        {
          titulo: 'Resumo — comerciais e virais',
          colunas: ['Produto', 'Material', 'Camada', 'Foco'],
          linhas: [
            ['Religioso', 'PLA/PLA Silk', '0,12–0,16 mm', 'Detalhe'],
            ['Pet', 'PETG', '0,2 mm', 'Durabilidade'],
            ['Articulado', 'PLA (print-in-place)', '0,16–0,2 mm', 'Margem'],
            ['Viral', 'PLA barato', '0,24–0,28 mm', 'Custo/volume'],
          ],
        },
      ],
      estrutura: {
        oQueFaz: 'Mostra como otimizar margem e volume em produtos de marketplace.',
        impactoTempo: 'Camada alta, bico grande e placas cheias maximizam peças/hora.',
        casosReais: [
          'Brinquedo articulado print-in-place: imprime já montado, sem mão de obra de montagem, e viraliza pelo "efeito uau".',
        ],
      },
      exercicios: [
        'Monte o perfil de um produto viral para custo mínimo e produção em lote.',
        'Calcule o lucro estimado de um brinquedo articulado vendido na Shopee.',
      ],
      testes: [
        'Por que produtos virais usam camada alta e bico grande?',
        'Por que o print-in-place aumenta a margem de um brinquedo articulado?',
      ],
      desafio:
        'EXAME DOS CASOS: escolha um produto novo (que não esteja na lista) e produza o estudo de caso completo — material, layer height, walls, infill, support, velocidade, custo, lucro estimado e justificativa técnica de cada decisão. Defenda por que essa é a configuração ideal para esse produto e canal de venda.',
      perguntas: [
        {
          pergunta: 'Como decidir rápido o material para um produto novo?',
          resposta:
            'Pergunte: ele sofre calor/sol (ASA/ABS), flexão/movimento (PETG/PLA+), precisa de detalhe estético (PLA/PLA Silk) ou é só visual barato e em volume (PLA comum)? A função e o ambiente definem o material antes de qualquer parâmetro de fatiamento.',
        },
        {
          pergunta: 'Dois produtos vendem igual, mas um dá muito mais lucro. Por quê?',
          resposta:
            'Geralmente o de maior lucro tem menor custo por peça: menos material (infill/paredes), camada mais alta, placa cheia e zero pós-processamento (ex.: print-in-place). O outro provavelmente consome mais material, tempo ou mão de obra. Otimize o custo por peça antes de baixar preço.',
        },
      ],
    },
  ],
}
