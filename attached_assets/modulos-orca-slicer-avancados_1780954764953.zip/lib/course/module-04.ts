import type { Modulo } from '@/lib/types'

export const modulo04: Modulo = {
  slug: 'materiais',
  numero: 4,
  titulo: 'Materiais',
  subtitulo: 'PLA, PETG, ABS, ASA, TPU, PC, Nylon e Compósitos CF',
  descricao:
    'Cada material tem temperatura, velocidade, ventilação, resistência, aplicações e problemas próprios. Conhecer o material é metade da batalha.',
  licoes: [
    {
      slug: 'pla-petg',
      titulo: 'PLA e PETG — Os pilares do dia a dia',
      resumo:
        'Os dois materiais mais usados: quando escolher cada um e como configurá-los.',
      duracao: '15 min',
      nivel: 'Iniciante',
      intro: [
        'PLA e PETG cobrem 80% das necessidades. PLA é fácil, rígido e detalhado, mas frágil e sensível a calor. PETG é mais resistente, flexível e resistente à temperatura, mas mais difícil de imprimir bem.',
      ],
      secoes: [
        {
          titulo: 'PLA',
          conteudo: [
            'Temperatura: bico 190–220 °C, mesa 50–60 °C.',
            'Velocidade: aceita alta (high-speed PLA até 250+ mm/s).',
            'Ventilação: 80–100%.',
            'Resistência: rígido e forte em compressão, mas frágil (quebra seco) e amolece a ~55–60 °C.',
            'Aplicações: protótipos, decoração, peças sem calor/sol.',
            'Problemas: deforma em carro quente; frágil sob impacto.',
          ],
        },
        {
          titulo: 'PETG',
          conteudo: [
            'Temperatura: bico 230–250 °C, mesa 70–85 °C.',
            'Velocidade: moderada (limitada por stringing).',
            'Ventilação: 30–50% (muito fan enfraquece camadas).',
            'Resistência: tenaz, resistente a impacto e a químicos, suporta ~70–80 °C.',
            'Aplicações: peças funcionais, externas, contato com água, suportes.',
            'Problemas: stringing, adere demais à mesa (pode arrancar PEI), sensível a umidade.',
          ],
        },
      ],
      estrutura: {
        oQueFaz:
          'Define o equilíbrio entre facilidade, rigidez e resistência térmica/impacto.',
        comoFunciona:
          'PLA cristaliza rápido e rígido; PETG é amorfo, mais tenaz e pegajoso.',
        quandoUsar:
          'PLA para detalhe e facilidade; PETG para função, calor moderado e tenacidade.',
        quandoEvitar:
          'Evite PLA em ambientes quentes/externos; evite PETG quando precisa de detalhe fino sem stringing.',
        impactoResistencia:
          'PETG resiste muito melhor a impacto e calor; PLA é mais rígido porém quebradiço.',
        impactoQualidade:
          'PLA dá acabamento mais limpo; PETG tende a stringing e blobs.',
        impactoTempo:
          'PLA permite velocidades maiores; PETG precisa ir mais devagar.',
        errosComuns: [
          'Imprimir PETG com fan 100% e obter camadas fracas.',
          'PETG grudando demais e danificando a mesa.',
        ],
        comoCorrigir: [
          'Reduza fan do PETG para 30–50%.',
          'Aumente a Z offset/use cola para criar barreira na mesa com PETG.',
        ],
        casosReais: [
          'Um suporte de celular para carro deve ser PETG (ou ABS), nunca PLA — o sol amolece o PLA em minutos.',
        ],
      },
      tabelas: [
        {
          titulo: 'PLA vs PETG',
          colunas: ['Critério', 'PLA', 'PETG'],
          linhas: [
            ['Facilidade', 'Altíssima', 'Média'],
            ['Resistência ao impacto', 'Baixa', 'Alta'],
            ['Resistência ao calor', '~55 °C', '~75 °C'],
            ['Detalhe', 'Excelente', 'Bom (stringing)'],
            ['Uso externo', 'Não', 'Sim (limitado por UV)'],
          ],
        },
      ],
      exercicios: [
        'Imprima a mesma peça em PLA e PETG e teste deixá-las no carro ao sol por 1 hora.',
        'Faça um teste de stringing com PETG variando temperatura e retração.',
      ],
      testes: [
        'Por que PETG não gosta de fan alto?',
        'Qual material escolher para uma peça que ficará no sol?',
      ],
      desafio:
        'Escolha o material para um suporte de mangueira de jardim exposto ao sol e à água. Justifique e defina temperatura e ventilação.',
    },
    {
      slug: 'abs-asa-tecnicos',
      titulo: 'ABS, ASA, TPU, PC, Nylon e CF',
      resumo:
        'Materiais técnicos e de engenharia: quando valem o esforço e como domá-los.',
      duracao: '20 min',
      nivel: 'Especialista',
      intro: [
        'Os materiais de engenharia entregam resistência mecânica e térmica superiores, mas exigem câmara fechada, secagem e controle térmico rigoroso. Aqui o operador precisa entender a física por trás do warping e da delaminação.',
      ],
      secoes: [
        {
          titulo: 'ABS e ASA',
          conteudo: [
            'Bico 240–260 °C, mesa 90–110 °C, fan baixíssimo (0–20%), idealmente câmara fechada.',
            'ASA é o "ABS resistente a UV" — ideal para uso externo.',
            'Resistência: boa ao impacto e calor (~95 °C). Problemas: warping severo, fumos (ventilar ambiente).',
          ],
        },
        {
          titulo: 'TPU (flexível)',
          conteudo: [
            'Bico 220–235 °C, mesa 40–60 °C, velocidade BAIXA (20–40 mm/s), retração mínima.',
            'Imprima com extrusor direct drive sempre que possível. Aplicações: capas, vedações, amortecedores.',
            'Problemas: emaranha no extrusor bowden, stringing.',
          ],
        },
        {
          titulo: 'PC, Nylon e compósitos de fibra de carbono (CF)',
          conteudo: [
            'PC: altíssima resistência térmica e mecânica, bico 260–300 °C, câmara aquecida. Higroscópico (seque sempre).',
            'Nylon (PA): tenaz e resistente a desgaste, mas absorve muita umidade — secagem obrigatória.',
            'CF (PLA-CF, PETG-CF, PA-CF): fibras aumentam rigidez e estabilidade dimensional, mas são abrasivas — exigem bico de aço endurecido.',
          ],
        },
      ],
      estrutura: {
        oQueFaz:
          'Entregam propriedades de engenharia: calor, impacto, flexibilidade ou rigidez extrema.',
        comoFunciona:
          'Polímeros de alta temperatura contraem ao esfriar (warping); umidade absorvida vira vapor e arruína a extrusão.',
        quandoUsar:
          'ABS/ASA para calor e externo; TPU para flexível; PC/Nylon para engenharia; CF para rigidez e estabilidade.',
        quandoEvitar:
          'Evite esses materiais sem câmara fechada (ABS/PC), secador (Nylon/PC) e bico endurecido (CF).',
        impactoResistencia:
          'Muito alta — mas só se warping e umidade forem controlados. CF aumenta rigidez mas pode reduzir tenacidade.',
        impactoQualidade:
          'CF dá acabamento fosco premium; warping arruína a planicidade se mal controlado.',
        impactoTempo:
          'Velocidades menores (TPU) e necessidade de controle térmico tornam o processo mais lento.',
        errosComuns: [
          'Imprimir Nylon/PC úmido (estala, bolhas, peça fraca).',
          'ABS sem câmara fechada (warping e rachaduras).',
          'CF em bico de latão (desgaste rápido do bico).',
        ],
        comoCorrigir: [
          'Seque o filamento (Nylon/PC: várias horas a 70–80 °C).',
          'Use câmara fechada e fan baixo para ABS/ASA/PC.',
          'Troque para bico de aço endurecido ao usar CF.',
        ],
        casosReais: [
          'Uma peça automotiva sob o capô precisa de PC ou Nylon-CF: ABS amoleceria, PLA derreteria.',
        ],
      },
      tabelas: [
        {
          titulo: 'Materiais técnicos — visão geral',
          colunas: ['Material', 'Resist. térmica', 'Destaque', 'Cuidado crítico'],
          linhas: [
            ['ABS', '~95 °C', 'Tenaz, usinável', 'Câmara/warping'],
            ['ASA', '~95 °C', 'Resistente a UV', 'Câmara/warping'],
            ['TPU', '~80 °C', 'Flexível', 'Velocidade baixa'],
            ['PC', '~110–130 °C', 'Resistência máxima', 'Secagem + câmara'],
            ['Nylon', '~100 °C', 'Tenaz/desgaste', 'Secagem obrigatória'],
            ['CF (compósito)', 'Varia base', 'Rigidez/estabilidade', 'Bico endurecido'],
          ],
        },
      ],
      exercicios: [
        'Pese um filamento de Nylon antes e depois de secar 6 h e observe a diferença de umidade.',
        'Imprima ABS com e sem brim/câmara e compare o warping.',
      ],
      testes: [
        'Por que materiais higroscópicos precisam ser secos?',
        'Por que CF exige bico de aço endurecido?',
      ],
      desafio:
        'Selecione o material para uma engrenagem que opera a 90 °C com atrito constante. Justifique e liste todos os cuidados de impressão.',
    },
  ],
}
