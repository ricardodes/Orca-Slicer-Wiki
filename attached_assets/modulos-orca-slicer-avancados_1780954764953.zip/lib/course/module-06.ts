import type { Modulo } from '@/lib/types'

export const modulo06: Modulo = {
  slug: 'engenharia',
  numero: 6,
  titulo: 'Engenharia Mecânica para Impressão 3D',
  subtitulo: 'Pense como engenheiro, não como operador',
  descricao:
    'Direção das camadas, tensões mecânicas, compressão, flexão, torção e cisalhamento. Aprenda a projetar e orientar peças que não quebram.',
  licoes: [
    {
      slug: 'direcao-camadas-tensoes',
      titulo: 'Direção das Camadas e Tipos de Tensão',
      resumo:
        'A anisotropia da impressão FDM e como compressão, flexão, torção e cisalhamento agem sobre a peça.',
      duracao: '20 min',
      nivel: 'Especialista',
      intro: [
        'Peças FDM são anisotrópicas: muito fortes ao longo das linhas e camadas, fracas entre camadas (eixo Z). Ignorar isso é a causa nº 1 de peças que quebram "sem motivo".',
        'O segredo da resistência não está em mais material, mas em orientar a peça para que as forças corram pela direção forte.',
      ],
      secoes: [
        {
          titulo: 'Anisotropia e direção das camadas',
          conteudo: [
            'A ligação entre camadas (Z) é a mais fraca — é onde a peça delamina sob tração.',
            'Ao longo de uma linha de extrusão a peça é quase tão forte quanto o material maciço.',
            'Regra de ouro: oriente a peça para que a maior força de tração fique paralela às camadas, nunca perpendicular.',
          ],
        },
        {
          titulo: 'Os cinco tipos de tensão',
          conteudo: [
            'Compressão: empurra/esmaga. FDM resiste bem (mais paredes e infill ajudam).',
            'Tração: estica. Fraca entre camadas — orientação crítica.',
            'Flexão: dobra. Combina tração de um lado e compressão do outro; paredes e orientação dominam.',
            'Torção: torce. Exige infill isotrópico (gyroid) e paredes robustas.',
            'Cisalhamento: forças paralelas opostas; tende a "deslizar" camadas — evite planos de camada alinhados ao corte.',
          ],
        },
      ],
      estrutura: {
        oQueFaz:
          'Relaciona a geometria e a orientação às forças reais que a peça vai sofrer.',
        comoFunciona:
          'Cada tipo de tensão tem uma direção; alinhar a direção forte da peça (camadas/linhas) com a maior carga maximiza a resistência.',
        quandoUsar:
          'Em todo projeto funcional: identifique a força dominante antes de orientar.',
        quandoEvitar:
          'Não oriente por conveniência de suporte se isso colocar a tração no eixo Z de uma peça crítica.',
        impactoResistencia:
          'Decisivo. A mesma peça pode ser 3–5x mais forte só mudando a orientação.',
        impactoQualidade:
          'Orientação ótima para resistência pode exigir suporte — equilibre com acabamento.',
        impactoTempo:
          'Orientações mais altas custam tempo; às vezes vale o trade-off por resistência.',
        errosComuns: [
          'Imprimir ganchos e alças com a carga perpendicular às camadas.',
          'Confiar só no infill para resistir à flexão.',
        ],
        comoCorrigir: [
          'Reoriente para alinhar a tração com as camadas.',
          'Aumente paredes e use gyroid para cargas multidirecionais.',
        ],
        casosReais: [
          'Um gancho impresso "deitado" (camadas paralelas à tração) aguenta vários quilos; o mesmo gancho "em pé" delamina com pouca carga.',
        ],
      },
      tabelas: [
        {
          titulo: 'Tensão × estratégia FDM',
          colunas: ['Tensão', 'FDM resiste?', 'Estratégia'],
          linhas: [
            ['Compressão', 'Bem', 'Mais paredes/infill'],
            ['Tração', 'Mal entre camadas', 'Orientar carga paralela às camadas'],
            ['Flexão', 'Médio', 'Paredes + orientação'],
            ['Torção', 'Médio', 'Gyroid + paredes'],
            ['Cisalhamento', 'Mal se alinhado a Z', 'Evitar plano de camada no corte'],
          ],
        },
      ],
      exercicios: [
        'Pegue um gancho e imprima em duas orientações; pendure peso crescente até falhar e registre.',
        'Projete uma alavanca e identifique onde ocorre tração, compressão e flexão.',
      ],
      testes: [
        'Qual é a direção mais fraca de uma peça FDM e por quê?',
        'Que infill escolher para torção e por quê?',
      ],
      desafio:
        'Você recebe uma peça que falha por flexão repetida. Redesenhe a orientação e a configuração de paredes/infill para maximizar a vida em fadiga. Justifique fisicamente.',
    },
  ],
}
