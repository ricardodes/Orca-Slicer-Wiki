import type { Modulo } from '@/lib/types'

export const modulo15: Modulo = {
  slug: 'producao-comercial',
  numero: 15,
  titulo: 'Produção Comercial e Otimização de Lucro',
  subtitulo: 'Transforme conhecimento técnico em negócio',
  descricao:
    'Calcule custo e lucro real, organize uma fazenda de impressão, controle qualidade, embale com profissionalismo e venda em Shopee, Mercado Livre e Amazon.',
  licoes: [
    {
      slug: 'custo-lucro',
      titulo: 'Cálculo de custo, lucro e tempo de máquina',
      resumo:
        'A fórmula real do preço: material, energia, máquina, falhas e margem.',
      duracao: '24 min',
      nivel: 'Avançado',
      intro: [
        'Quem vende impressão 3D olhando só o preço do filamento fecha o negócio no prejuízo. O custo real tem várias camadas.',
        'O profissional precifica com método: soma todos os custos, aplica taxa de falha e marketplace, e só então a margem de lucro.',
      ],
      secoes: [
        {
          titulo: 'Os componentes do custo',
          conteudo: [
            'Material: gramas da peça × preço por grama do filamento.',
            'Energia: potência média (kW) × horas × tarifa por kWh.',
            'Tempo de máquina: depreciação da impressora + manutenção, rateados por hora de uso.',
            'Mão de obra: tempo de preparo, pós-processamento e embalagem.',
            'Taxa de falha: some 5–15% para cobrir peças refugadas.',
          ],
        },
        {
          titulo: 'A fórmula de precificação',
          conteudo: [
            'Custo total = material + energia + máquina/hora × horas + mão de obra.',
            'Preço de venda = custo total × multiplicador (2x a 4x conforme o produto e o canal).',
            'Desconte ainda a comissão do marketplace e o frete antes de definir o lucro líquido.',
          ],
        },
      ],
      tabelas: [
        {
          titulo: 'Exemplo de custo de uma peça (50 g, 3 h)',
          colunas: ['Item', 'Cálculo', 'Valor'],
          linhas: [
            ['Material', '50 g × R$0,08/g', 'R$ 4,00'],
            ['Energia', '0,15 kW × 3 h × R$0,90', 'R$ 0,40'],
            ['Máquina/hora', '3 h × R$0,50', 'R$ 1,50'],
            ['Mão de obra', '15 min preparo/embalagem', 'R$ 3,00'],
            ['Custo total', 'soma + 10% falha', '~R$ 9,79'],
            ['Preço (3x)', 'custo × 3', '~R$ 29,00'],
          ],
        },
      ],
      estrutura: {
        oQueFaz: 'Define um preço que cobre todos os custos e ainda gera lucro real.',
        errosComuns: [
          'Precificar só pelo filamento.',
          'Esquecer comissão do marketplace e frete.',
          'Não reservar margem para falhas.',
        ],
        comoCorrigir: [
          'Use a fórmula completa de custo.',
          'Desconte taxas do canal antes da margem.',
        ],
      },
      exercicios: [
        'Calcule o custo total real de uma peça sua usando a fórmula completa.',
        'Defina o preço de venda para uma margem líquida de 3x após comissão da Shopee.',
      ],
      testes: [
        'Quais são os cinco componentes do custo de uma peça?',
        'Por que precificar só pelo filamento leva ao prejuízo?',
      ],
    },
    {
      slug: 'producao-lote-fazenda',
      titulo: 'Produção em lote e fazenda de impressão',
      resumo:
        'Escale de uma para várias impressoras com organização e padronização.',
      duracao: '22 min',
      nivel: 'Especialista',
      intro: [
        'Vender uma peça é fácil; vender 300 por semana exige um sistema. É aqui que a impressão vira indústria.',
      ],
      secoes: [
        {
          titulo: 'Otimização de produção em lote',
          conteudo: [
            'Encha a placa: agrupe o máximo de peças por placa para diluir o tempo de aquecimento e o trabalho de troca.',
            'Padronize um perfil comercial: bico maior, infill enxuto, velocidade equilibrada — o mesmo para todo o lote.',
            'Separe por cor e material para evitar trocas constantes de filamento.',
          ],
        },
        {
          titulo: 'Organização da fazenda de impressão',
          conteudo: [
            'Várias impressoras idênticas facilitam manutenção e perfis intercambiáveis.',
            'Numere as máquinas e mantenha registro de horas e manutenções de cada uma.',
            'Tenha estoque de peças de reposição (bicos, correias, sensores) para não parar a produção.',
            'Fluxo: fila de pedidos → fatiamento padronizado → impressão → pós-processo → controle de qualidade → embalagem → expedição.',
          ],
        },
      ],
      estrutura: {
        oQueFaz: 'Transforma impressão artesanal em produção previsível e escalável.',
        impactoTempo: 'Placas cheias e perfis padronizados reduzem drasticamente o custo por peça.',
        casosReais: [
          'Um maker passou de 20 para 200 peças/semana só padronizando o perfil e enchendo as placas, sem comprar máquina nova.',
        ],
      },
      exercicios: [
        'Monte uma placa cheia de um produto seu e calcule o custo por peça vs. imprimir uma só.',
        'Desenhe o fluxo de produção da sua operação, do pedido à expedição.',
      ],
      testes: [
        'Por que encher a placa reduz o custo por peça?',
        'Por que padronizar um único perfil comercial ajuda na escala?',
      ],
    },
    {
      slug: 'qualidade-embalagem-marketplaces',
      titulo: 'Controle de qualidade, embalagem e marketplaces',
      resumo:
        'Da inspeção final à venda em Shopee, Mercado Livre e Amazon.',
      duracao: '24 min',
      nivel: 'Especialista',
      intro: [
        'A última etapa define a reputação: uma peça bem feita mal embalada ou mal anunciada gera devolução e avaliação ruim.',
      ],
      secoes: [
        {
          titulo: 'Controle de qualidade',
          conteudo: [
            'Crie um checklist: dimensões, acabamento da seam, ausência de stringing, encaixe funcional.',
            'Defina um padrão de aprovação e refugue (ou reprocesse) o que não passar.',
            'Registre o índice de falhas para melhorar perfis e reduzir desperdício.',
          ],
        },
        {
          titulo: 'Embalagem',
          conteudo: [
            'Proteja peças frágeis com plástico-bolha e caixa rígida — peças impressas quebram em queda.',
            'Embalagem com marca (etiqueta, cartão de agradecimento) aumenta percepção de valor e avaliações positivas.',
            'Otimize peso e dimensões para baratear o frete.',
          ],
        },
        {
          titulo: 'Marketplaces',
          conteudo: [
            'Shopee: alto volume, público sensível a preço, comissão e frete subsidiado; bom para produtos virais baratos.',
            'Mercado Livre: público disposto a pagar mais, forte em funcionais e nichos; reputação e Mercado Envios são decisivos.',
            'Amazon: ticket médio maior, exige boa apresentação e logística; ótimo para produtos premium e de nicho.',
            'Em todos: fotos boas, título com palavras-chave, descrição clara e respostas rápidas vendem mais que preço baixo.',
          ],
        },
      ],
      tabelas: [
        {
          titulo: 'Comparativo de marketplaces',
          colunas: ['Canal', 'Público', 'Melhor para'],
          linhas: [
            ['Shopee', 'Sensível a preço', 'Produtos virais baratos'],
            ['Mercado Livre', 'Paga por qualidade', 'Funcionais e nichos'],
            ['Amazon', 'Ticket alto', 'Premium e nicho'],
          ],
        },
      ],
      estrutura: {
        oQueFaz: 'Garante qualidade consistente e leva o produto ao cliente certo.',
        errosComuns: [
          'Embalagem fraca que deixa a peça chegar quebrada.',
          'Anúncio com foto ruim e título sem palavras-chave.',
        ],
        comoCorrigir: [
          'Adote checklist de QC e embalagem protetora.',
          'Capriche em fotos, título e descrição.',
        ],
      },
      exercicios: [
        'Crie o checklist de controle de qualidade do seu produto.',
        'Escreva um título otimizado e tire 3 fotos de um produto para anúncio.',
      ],
      testes: [
        'Quais itens não podem faltar num checklist de QC?',
        'Qual marketplace tende a aceitar ticket mais alto e por quê?',
      ],
      desafio:
        'Escolha um produto seu e monte o plano comercial completo: custo real, preço por canal (Shopee, ML e Amazon) descontando comissões, embalagem, checklist de QC e o anúncio (título + descrição + fotos). Apresente a margem líquida estimada em cada canal.',
      perguntas: [
        {
          pergunta: 'Vendo barato e tenho muitos pedidos, mas não sobra dinheiro. O que revisar?',
          resposta:
            'Refaça o cálculo de custo completo (material, energia, máquina, mão de obra, falhas) e desconte comissão e frete. Provavelmente o multiplicador está baixo ou você ignorou custos ocultos. Aumente o preço, reduza o custo por peça (placas cheias, bico maior) ou migre para um canal de ticket mais alto.',
        },
        {
          pergunta: 'Mesmo produto: vendo na Shopee ou na Amazon?',
          resposta:
            'Depende do produto. Itens virais e baratos giram melhor na Shopee, no volume. Produtos premium, funcionais ou de nicho rendem margem maior na Amazon e no Mercado Livre. O ideal é estar em mais de um canal com preços ajustados às comissões de cada um.',
        },
      ],
    },
  ],
}
