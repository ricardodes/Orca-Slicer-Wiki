import type { Modulo } from '@/lib/types'

export const modulo03: Modulo = {
  slug: 'processo',
  numero: 3,
  titulo: 'Configurações de Processo',
  subtitulo: 'O coração do fatiamento',
  descricao:
    'Cada parâmetro que define como sua peça é construída: Quality, Walls, Top/Bottom, Infill, Speed, Acceleration, Cooling, Support e Adhesion. Aqui mora 70% das suas decisões técnicas.',
  licoes: [
    {
      slug: 'quality-camadas',
      titulo: 'Quality — Altura de Camada e Camadas Adaptativas',
      resumo:
        'Layer height, first layer height, adaptive layer e variable layer height.',
      duracao: '16 min',
      nivel: 'Intermediário',
      intro: [
        'A altura de camada é o parâmetro de qualidade mais visível e o de maior impacto no tempo. Camadas finas = mais detalhe e mais tempo; camadas grossas = rápido e robusto, porém com "degraus" visíveis.',
        'A primeira camada é especial: ela define se a peça gruda. Quase todo fracasso de impressão começa (ou não) na primeira camada.',
      ],
      secoes: [
        {
          titulo: 'Layer Height',
          conteudo: [
            'Define a espessura de cada fatia em Z. Regra: entre 25% e 75% do diâmetro do bico (0,1–0,3 mm para bico 0,4).',
            'O tempo é quase inversamente proporcional: passar de 0,2 para 0,1 mm aproximadamente DOBRA o tempo.',
            'Camadas mais finas melhoram superfícies curvas e overhangs, mas não melhoram a precisão XY (isso são as paredes).',
          ],
        },
        {
          titulo: 'First Layer Height',
          conteudo: [
            'A primeira camada costuma ser mais grossa (0,2–0,3 mm) para tolerar pequenas imperfeições de nivelamento e melhorar adesão.',
            'Uma primeira camada bem calibrada (altura + temperatura + velocidade baixa) resolve a maioria dos problemas de aderência.',
          ],
        },
        {
          titulo: 'Adaptive & Variable Layer Height',
          conteudo: [
            'Adaptive layer height varia automaticamente a espessura conforme a inclinação da superfície: fina em áreas curvas, grossa em paredes verticais — otimizando tempo x qualidade.',
            'Variable layer height permite você "pintar" manualmente onde quer camadas mais finas (ex.: rosto de um busto) e mais grossas no resto.',
          ],
        },
      ],
      estrutura: {
        oQueFaz:
          'Controla a resolução vertical da impressão e a robustez da base.',
        comoFunciona:
          'Cada camada é uma fatia horizontal da malha. Mais fatias = mais detalhe vertical e mais movimentos = mais tempo.',
        quandoUsar:
          '0,12–0,16 mm para qualidade visual; 0,2 mm para uso geral; 0,28–0,3 mm para peças funcionais rápidas.',
        quandoEvitar:
          'Evite camadas finas em peças puramente funcionais (desperdício de tempo) e camadas grossas em superfícies curvas visíveis.',
        impactoResistencia:
          'Camadas mais grossas tendem a ser ligeiramente mais fortes em Z (menos interfaces entre camadas) e mais rápidas.',
        impactoQualidade:
          'Camadas finas suavizam curvas e overhangs; grossas mostram degraus (stair-stepping).',
        impactoTempo:
          'Impacto dominante: tempo escala inversamente com a altura de camada.',
        impactoFilamento:
          'Pouco efeito no volume total (mesmo objeto), mas adaptive reduz tempo sem aumentar material.',
        errosComuns: [
          'Usar layer height maior que 75% do bico (linhas não fundem bem).',
          'Primeira camada fina demais em mesa não perfeitamente nivelada.',
        ],
        comoCorrigir: [
          'Mantenha layer height ≤ 75% do bico.',
          'Aumente a primeira camada para 0,25 mm e reduza a velocidade dela.',
        ],
        casosReais: [
          'Um busto decorativo usa variable layer height: 0,08 mm no rosto e 0,24 mm na base — qualidade onde importa, velocidade onde não.',
        ],
      },
      tabelas: [
        {
          titulo: 'Altura de camada (bico 0,4 mm)',
          colunas: ['Altura', 'Qualidade', 'Tempo', 'Uso'],
          linhas: [
            ['0,08–0,12 mm', 'Excelente', 'Muito alto', 'Detalhe fino'],
            ['0,16 mm', 'Muito boa', 'Alto', 'Qualidade/uso'],
            ['0,20 mm', 'Boa', 'Médio', 'Padrão geral'],
            ['0,28–0,30 mm', 'Funcional', 'Baixo', 'Peças robustas rápidas'],
          ],
        },
      ],
      exercicios: [
        'Fatie a mesma peça em 0,12 / 0,20 / 0,28 mm e registre tempo e consumo.',
        'Aplique adaptive layer height numa peça com partes curvas e verticais e compare o tempo com altura fixa.',
      ],
      testes: [
        'Quanto aproximadamente aumenta o tempo ao reduzir de 0,2 para 0,1 mm?',
        'A altura de camada melhora a precisão XY?',
      ],
      desafio:
        'Para uma engrenagem funcional, escolha a altura de camada ideal equilibrando resistência, tempo e qualidade dos dentes. Justifique.',
    },
    {
      slug: 'walls-paredes',
      titulo: 'Walls — Paredes, Geradores e Gap Fill',
      resumo:
        'Wall loops, wall generator (Classic vs Arachne), thin walls, gap fill e detect thin wall.',
      duracao: '17 min',
      nivel: 'Avançado',
      intro: [
        'As paredes (perímetros) são o principal fator de resistência de uma peça — muito mais que o infill. Elas formam a "casca" estrutural.',
        'O OrcaSlicer oferece dois geradores de parede: Classic (largura constante) e Arachne (largura variável), cada um com vantagens distintas.',
      ],
      secoes: [
        {
          titulo: 'Wall Loops (número de perímetros)',
          conteudo: [
            'Cada loop é uma volta da parede. 2 loops é o mínimo prático; 3–4 para peças funcionais; 5+ para alta resistência.',
            'Aumentar paredes é a forma MAIS eficiente de ganhar resistência — mais eficaz que aumentar infill.',
          ],
        },
        {
          titulo: 'Wall Generator: Classic vs Arachne',
          conteudo: [
            'Classic: perímetros de largura fixa. Previsível, mas deixa vãos em paredes finas que precisam de gap fill.',
            'Arachne: ajusta a largura da linha dinamicamente para preencher paredes de espessura irregular sem vãos. Melhor para letras, detalhes finos e geometria variável.',
          ],
        },
        {
          titulo: 'Thin Walls, Detect Thin Wall e Gap Fill',
          conteudo: [
            'Detect thin wall identifica paredes mais finas que uma linha e tenta imprimi-las mesmo assim.',
            'Gap fill preenche pequenos vãos entre paredes com traços finos. Em excesso pode gerar superextrusão e ruído; pode ser limitado ou desativado.',
          ],
        },
      ],
      estrutura: {
        oQueFaz:
          'Define a casca estrutural da peça e como espaços estreitos são preenchidos.',
        comoFunciona:
          'O gerador calcula caminhos de perímetro de dentro para fora (ou vice-versa). Arachne usa o algoritmo de "skeleton" para larguras variáveis.',
        quandoUsar:
          'Arachne para peças com detalhes e espessuras variáveis; mais wall loops para resistência.',
        quandoEvitar:
          'Evite gap fill agressivo em superfícies visíveis (gera blobs); evite poucas paredes em peças sob carga.',
        impactoResistencia:
          'Altíssimo: paredes são o principal contribuinte da resistência. 4 paredes + 15% infill costuma superar 2 paredes + 50% infill em peso e força.',
        impactoQualidade:
          'Arachne melhora muito a fidelidade de letras e detalhes finos; gap fill mal calibrado piora.',
        impactoTempo:
          'Cada parede extra adiciona tempo proporcional ao perímetro × altura.',
        impactoFilamento:
          'Paredes consomem material previsível; ainda assim, mais paredes + menos infill pode ser mais eficiente que o contrário.',
        errosComuns: [
          'Confiar no infill alto em vez de paredes para resistência (ineficiente).',
          'Gap fill gerando blobs e ruído em paredes finas.',
        ],
        comoCorrigir: [
          'Para resistência, priorize wall loops antes de aumentar densidade de infill.',
          'Troque para Arachne ou limite o gap fill se houver superextrusão.',
        ],
        casosReais: [
          'Um suporte de parede que precisa segurar peso: 5 paredes + 20% gyroid é mais forte e mais leve que 2 paredes + 60% grid.',
        ],
      },
      tabelas: [
        {
          titulo: 'Paredes vs Infill para resistência',
          colunas: ['Configuração', 'Resistência', 'Peso', 'Tempo'],
          linhas: [
            ['2 paredes / 50% infill', 'Média', 'Alto', 'Alto'],
            ['4 paredes / 15% infill', 'Alta', 'Médio', 'Médio'],
            ['5 paredes / 20% infill', 'Muito alta', 'Médio', 'Alto'],
          ],
        },
      ],
      exercicios: [
        'Fatie um cubo com 2, 3 e 5 paredes e compare consumo e tempo.',
        'Imprima um texto em relevo com gerador Classic e Arachne e compare a fidelidade.',
      ],
      testes: [
        'O que dá mais resistência por grama: paredes ou infill?',
        'Quando o gerador Arachne é claramente superior?',
      ],
      desafio:
        'Projete a configuração de paredes para um gancho que segurará 10 kg, minimizando peso. Justifique o número de loops e o gerador escolhido.',
    },
    {
      slug: 'top-bottom-infill',
      titulo: 'Top/Bottom e Infill — Densidade e Padrões',
      resumo:
        'Camadas superiores/inferiores, padrões de superfície e todos os tipos de infill (Gyroid, Cubic, Honeycomb, Lightning, etc.).',
      duracao: '20 min',
      nivel: 'Avançado',
      intro: [
        'As camadas de topo e fundo fecham a peça; o infill a preenche internamente. Escolher o padrão e a densidade certos define resistência, peso, tempo e até comportamento sob diferentes tipos de força.',
        'Não existe "melhor infill" — existe o infill certo para o tipo de carga que a peça vai sofrer.',
      ],
      secoes: [
        {
          titulo: 'Top/Bottom Layers e Surface Patterns',
          conteudo: [
            'O número de camadas de topo/fundo (geralmente 3–5) garante uma superfície fechada e resistente. Poucas camadas deixam "pillowing" (buracos no topo).',
            'Padrões de superfície (Monotonic, Concentric, etc.): Monotonic dá o acabamento de topo mais uniforme; Concentric segue o contorno.',
            'Regra: a espessura total de topo (camadas × altura) deve ser ~0,8–1,2 mm para fechar bem.',
          ],
        },
        {
          titulo: 'Densidade de Infill',
          conteudo: [
            '0% para peças ocas (vasos); 10–20% uso geral; 30–50% peças funcionais; 100% só para máxima resistência/peso (raro).',
            'A relação densidade × resistência NÃO é linear: dobrar de 20% para 40% não dobra a resistência e quase dobra o tempo.',
          ],
        },
        {
          titulo: 'Tipos de Infill',
          conteudo: [
            'Gyroid: isotrópico (resiste igual em todas as direções), ótimo equilíbrio resistência/peso/flexibilidade. Excelente padrão geral.',
            'Cubic / Adaptive Cubic: forte em 3D, adaptive reduz material no centro mantendo suporte ao topo.',
            'Grid: rápido e simples, mas as linhas se cruzam (pode gerar ruído/colisão do bico).',
            'Triangles / Tri-hexagon: bom para resistência em paredes, mais rígido lateralmente.',
            'Honeycomb: muito forte, mas lento.',
            'Lightning: mínimo material, serve APENAS para sustentar o topo (peças decorativas), sem resistência estrutural.',
            'Cross Hatch: bom para flexibilidade e estética em peças com paredes finas.',
          ],
        },
      ],
      estrutura: {
        oQueFaz:
          'Fecha as superfícies e preenche o interior dando rigidez e suporte às camadas de topo.',
        comoFunciona:
          'O infill é uma malha interna que conecta as paredes e sustenta o topo. O padrão define a direção e a isotropia da resistência.',
        quandoUsar:
          'Gyroid para uso geral/funcional; Lightning para decorativo; Adaptive Cubic para grande+leve; Grid para velocidade.',
        quandoEvitar:
          'Evite Lightning em peças estruturais; evite 100% de infill exceto necessidade real (tempo e material enormes).',
        impactoResistencia:
          'Padrão importa tanto quanto densidade. Gyroid é isotrópico; Grid/Triangles são direcionais.',
        impactoQualidade:
          'Top layers insuficientes causam pillowing; padrão de superfície afeta o acabamento do topo.',
        impactoTempo:
          'Lightning e baixa densidade são rapidíssimos; Honeycomb e alta densidade são lentos.',
        impactoFilamento:
          'Densidade e padrão definem o consumo interno — maior alavanca de economia depois do suporte.',
        errosComuns: [
          'Pillowing por poucas camadas de topo.',
          'Usar 50%+ de infill achando que aumenta muito a resistência (ineficiente).',
          'Lightning em peça funcional que quebra na primeira carga.',
        ],
        comoCorrigir: [
          'Aumente para 4–5 top layers ou densidade de infill se houver pillowing.',
          'Priorize paredes; use 15–25% gyroid para a maioria das peças funcionais.',
        ],
        casosReais: [
          'Caixa organizadora grande: 15% gyroid + 3 paredes = leve, rígida e econômica. Trocar para 40% grid só aumentaria peso e tempo sem ganho prático.',
        ],
      },
      tabelas: [
        {
          titulo: 'Guia rápido de infill',
          colunas: ['Padrão', 'Resistência', 'Velocidade', 'Material', 'Melhor para'],
          linhas: [
            ['Gyroid', 'Alta (isotrópica)', 'Média', 'Médio', 'Uso geral / funcional'],
            ['Adaptive Cubic', 'Alta', 'Média-Alta', 'Baixo', 'Peças grandes e leves'],
            ['Grid', 'Média (direcional)', 'Alta', 'Médio', 'Protótipos rápidos'],
            ['Honeycomb', 'Muito alta', 'Baixa', 'Alto', 'Máxima resistência'],
            ['Lightning', 'Mínima', 'Altíssima', 'Mínimo', 'Decorativo (só sustenta topo)'],
            ['Cross Hatch', 'Média', 'Média', 'Médio', 'Flexível / estético'],
          ],
        },
      ],
      exercicios: [
        'Fatie a mesma caixa com Gyroid 15%, Grid 15% e Lightning e compare tempo e material.',
        'Imprima uma tampa plana com 2, 3 e 5 top layers e observe o pillowing.',
      ],
      testes: [
        'Qual infill é isotrópico e por que isso importa?',
        'Por que Lightning não serve para peças funcionais?',
      ],
      desafio:
        'Uma peça vai sofrer compressão vertical e leve torção. Escolha padrão e densidade de infill ideais, justificando com base na direção das forças.',
    },
    {
      slug: 'speed-acceleration',
      titulo: 'Speed e Acceleration — Velocidade e Otimização',
      resumo:
        'Todas as velocidades, relação velocidade × qualidade e como otimizar a aceleração.',
      duracao: '18 min',
      nivel: 'Avançado',
      intro: [
        'Velocidade não é um número único: o OrcaSlicer tem dezenas de velocidades específicas (paredes externas, internas, infill, topo, ponte, primeira camada...). Otimizar significa saber onde ir devagar e onde acelerar.',
        'A regra de ouro: vá DEVAGAR onde a qualidade aparece (paredes externas, overhangs) e RÁPIDO onde ninguém vê (infill).',
      ],
      secoes: [
        {
          titulo: 'As velocidades principais',
          conteudo: [
            'Outer wall (parede externa): a mais importante para qualidade visual — mantenha moderada (50–150 mm/s conforme a máquina).',
            'Inner wall: pode ser mais rápida que a externa (não é visível).',
            'Infill / Sparse infill: a mais rápida possível dentro do limite de fluxo.',
            'Top surface: moderada para acabamento liso.',
            'First layer: sempre lenta (20–30 mm/s) para adesão.',
            'Bridge / overhang: lentas para evitar queda do filamento.',
          ],
        },
        {
          titulo: 'Relação velocidade × qualidade',
          conteudo: [
            'Velocidade alta gera mais vibração (ringing), pior controle de extrusão e overhangs ruins.',
            'O gargalo real costuma ser fluxo volumétrico e aceleração, não a velocidade máxima nominal.',
          ],
        },
        {
          titulo: 'Otimizando aceleração',
          conteudo: [
            'Acelerações separadas por tipo de movimento (outer wall, infill, travel). Reduza a aceleração das paredes externas para qualidade; aumente a do infill e travel para velocidade.',
            'Calibrar Input Shaper (Módulo 5) é o que permite acelerações altas sem ghosting.',
          ],
        },
      ],
      estrutura: {
        oQueFaz:
          'Controla a rapidez de cada tipo de movimento, equilibrando tempo e qualidade.',
        comoFunciona:
          'O firmware acelera até a velocidade alvo respeitando aceleração e fluxo. Em segmentos curtos, raramente atinge a velocidade máxima.',
        quandoUsar:
          'Diferencie: lento em outer wall/overhang/first layer; rápido em inner wall/infill/travel.',
        quandoEvitar:
          'Não aumente a velocidade da parede externa buscando tempo — o ganho é pequeno e a qualidade despenca.',
        impactoResistencia:
          'Velocidade excessiva reduz a adesão entre linhas e camadas (extrusão menos consistente), enfraquecendo a peça.',
        impactoQualidade:
          'Parede externa lenta = superfície limpa. Rápida = ringing e cantos arredondados.',
        impactoTempo:
          'Infill e travel rápidos dão o maior ganho de tempo com mínimo custo de qualidade.',
        impactoFilamento:
          'Neutro no consumo; afeta principalmente tempo e qualidade.',
        errosComuns: [
          'Subir todas as velocidades igualmente e perder qualidade nas paredes.',
          'First layer rápida demais causando má adesão.',
        ],
        comoCorrigir: [
          'Reduza apenas a velocidade da outer wall e dos overhangs.',
          'Reduza a first layer para 20–30 mm/s.',
        ],
        casosReais: [
          'Para acabamento premium num produto à venda: outer wall a 80 mm/s, inner wall a 200 mm/s, infill a 250 mm/s — qualidade onde se vê, velocidade onde não.',
        ],
      },
      tabelas: [
        {
          titulo: 'Estratégia de velocidade',
          colunas: ['Movimento', 'Velocidade', 'Motivo'],
          linhas: [
            ['Primeira camada', 'Muito baixa', 'Adesão'],
            ['Parede externa', 'Baixa-média', 'Qualidade visual'],
            ['Parede interna', 'Alta', 'Não é visível'],
            ['Infill', 'Máxima (limite de fluxo)', 'Não é visível'],
            ['Overhang/Bridge', 'Baixa', 'Evitar queda'],
            ['Travel', 'Alta', 'Reduz tempo e oozing'],
          ],
        },
      ],
      exercicios: [
        'Imprima um cubo com outer wall a 60 e a 200 mm/s e compare a superfície.',
        'Aumente só infill e travel e meça quanto tempo economiza sem afetar a aparência.',
      ],
      testes: [
        'Por que aumentar a velocidade da parede externa é uma má estratégia de economia de tempo?',
        'Qual costuma ser o verdadeiro gargalo de velocidade?',
      ],
      desafio:
        'Otimize um perfil para cortar 25% do tempo de uma peça SEM perda visível de qualidade. Liste exatamente quais velocidades você alterou e por quê.',
    },
    {
      slug: 'cooling-support-adhesion',
      titulo: 'Cooling, Support e Adhesion',
      resumo:
        'Ventilação e controle térmico, tipos de suporte (Normal, Tree, Organic) e adesão (Brim, Raft, Skirt).',
      duracao: '22 min',
      nivel: 'Avançado',
      intro: [
        'Resfriamento, suporte e adesão são os três pilares que decidem se uma peça difícil vai dar certo. Cada material tem necessidades opostas de cooling, e o suporte mal escolhido arruína superfícies.',
        'Dominar esses três grupos é o que separa quem "tenta imprimir" de quem "garante a impressão".',
      ],
      secoes: [
        {
          titulo: 'Cooling (resfriamento)',
          conteudo: [
            'A ventoinha de peça solidifica o filamento recém-depositado. Essencial para PLA (overhangs, detalhes); prejudicial em excesso para ABS/ASA (warping, delaminação).',
            'Tempo mínimo de camada: garante que camadas pequenas não sejam empilhadas quente sobre quente — o slicer desacelera para dar tempo de esfriar.',
            'Controle térmico por camada: a primeira camada normalmente tem fan 0% para adesão.',
          ],
        },
        {
          titulo: 'Support — tipos',
          conteudo: [
            'Normal (grid/snug): pilares verticais. Forte e confiável, mas difícil de remover e marca a superfície.',
            'Tree Support: galhos que crescem em direção aos overhangs. Usa menos material, remove mais fácil.',
            'Organic: versão evoluída do tree, com galhos mais inteligentes e suaves — melhor para figuras e orgânicos.',
            'Interface Layers: camadas densas entre o suporte e a peça que melhoram o acabamento da face apoiada.',
            'Z distance / XY distance: a folga entre suporte e peça. Pequena = melhor acabamento porém difícil de remover; grande = fácil remover porém superfície pior.',
          ],
        },
        {
          titulo: 'Adhesion — Skirt, Brim e Raft',
          conteudo: [
            'Skirt: linha ao redor da peça (não toca nela) que "prepara" o fluxo do bico. Não ajuda na adesão diretamente.',
            'Brim: borda colada à base da peça que aumenta a área de contato — ótimo contra warping e para peças com base pequena.',
            'Raft: base completa impressa sob a peça. Máxima adesão e tolerância a mesa irregular, mas gasta material e tempo e piora a superfície de baixo.',
          ],
        },
      ],
      estrutura: {
        oQueFaz:
          'Cooling controla solidificação; Support sustenta overhangs; Adhesion garante que a peça não solte da mesa.',
        comoFunciona:
          'O fan resfria a camada nova; o suporte cria estrutura removível sob overhangs; brim/raft aumentam a área aderida.',
        quandoUsar:
          'Cooling alto para PLA; baixo para ABS/ASA. Tree/Organic para figuras; Normal para blocos. Brim para bases pequenas/warping; Raft só quando a mesa é problemática.',
        quandoEvitar:
          'Evite fan alto em ABS/ASA (warping); evite raft quando brim resolve (desperdício); evite suporte onde reorientar resolveria.',
        impactoResistencia:
          'Cooling excessivo em ABS reduz adesão entre camadas (peça frágil). Suporte não afeta resistência da peça final.',
        impactoQualidade:
          'Cooling correto melhora overhangs e detalhes. Z distance pequena = superfície apoiada melhor. Raft piora a base.',
        impactoTempo:
          'Suporte (especialmente normal denso) e raft adicionam tempo significativo. Tree/Organic economizam.',
        impactoFilamento:
          'Suporte e raft são as maiores fontes de desperdício de filamento — minimizá-los é prioridade comercial.',
        errosComuns: [
          'Fan 100% em ABS causando warping e rachaduras entre camadas.',
          'Z distance grande demais deixando a superfície apoiada horrível.',
          'Usar raft quando um brim de 5 mm bastava.',
        ],
        comoCorrigir: [
          'Reduza/desligue o fan para ABS/ASA; aumente para PLA em overhangs.',
          'Ajuste a Z distance para o mínimo que ainda permita remoção.',
          'Prefira brim a raft sempre que possível.',
        ],
        casosReais: [
          'Uma miniatura com muitos overhangs usa Organic support com interface densa e Z distance baixa: remoção limpa e faces lisas.',
        ],
      },
      tabelas: [
        {
          titulo: 'Cooling por material',
          colunas: ['Material', 'Fan', 'Risco se errar'],
          linhas: [
            ['PLA', '80–100%', 'Overhang ruim se baixo'],
            ['PETG', '30–50%', 'Stringing se alto; fraco se muito'],
            ['ABS/ASA', '0–20%', 'Warping/delaminação se alto'],
            ['TPU', '20–50%', 'Stringing e detalhe'],
          ],
        },
        {
          titulo: 'Tipos de suporte',
          colunas: ['Tipo', 'Material usado', 'Remoção', 'Melhor para'],
          linhas: [
            ['Normal', 'Alto', 'Difícil', 'Blocos, peças grandes'],
            ['Tree', 'Baixo', 'Fácil', 'Uso geral, overhangs isolados'],
            ['Organic', 'Baixo', 'Fácil', 'Figuras, formas orgânicas'],
          ],
        },
      ],
      exercicios: [
        'Imprima um overhang de teste com fan 30% e 100% em PLA e compare.',
        'Gere suporte Normal, Tree e Organic na mesma figura e compare material e facilidade de remoção.',
        'Imprima uma peça de base pequena com skirt, brim e raft e observe a adesão e a superfície de baixo.',
      ],
      testes: [
        'Por que ABS não gosta de fan alto?',
        'Qual a diferença prática entre brim e raft?',
        'O que a Z distance controla?',
      ],
      desafio:
        'Você vai imprimir uma figura orgânica em PLA com vários overhangs e uma base pequena. Defina cooling, tipo de suporte, Z distance e tipo de adesão ideais e justifique cada escolha.',
    },
  ],
}
