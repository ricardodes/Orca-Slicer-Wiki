import type { Modulo } from '@/lib/types'

export const modulo10: Modulo = {
  slug: 'mestre',
  numero: 10,
  titulo: 'Mestre do OrcaSlicer',
  subtitulo: 'O exame final do especialista',
  descricao:
    'Desafios integrados, simulação de problemas reais, perguntas técnicas e avaliação. Aqui você prova que sabe escolher a configuração ideal para qualquer peça.',
  licoes: [
    {
      slug: 'avaliacao-final',
      titulo: 'Desafios Integrados e Diagnóstico de Problemas',
      resumo:
        'Simulações reais: dado um defeito ou objetivo, você decide a solução completa.',
      duracao: '30 min',
      nivel: 'Especialista',
      intro: [
        'O especialista absoluto não decora valores — raciocina. Diante de qualquer peça ou defeito, equilibra custo, tempo, resistência, acabamento e lucro.',
        'Estes desafios integram todos os módulos. Para cada um, explique o raciocínio técnico, não só a resposta.',
      ],
      secoes: [
        {
          titulo: 'Diagnóstico de defeitos (simulação)',
          conteudo: [
            'Cantos com bolhas e "orelhas" → Pressure Advance descalibrado.',
            'Ecos/sombras nas paredes (ghosting) → aceleração alta sem Input Shaper.',
            'Topo com buracos (pillowing) → poucas top layers / fan / infill baixo.',
            'Peça delamina sob carga → orientação errada (tração no Z) ou temperatura baixa.',
            'Fios entre torres (stringing) → retração/temperatura; comum em PETG.',
            'Warping nos cantos → falta de câmara/brim, fan alto em ABS, mesa fria.',
          ],
        },
        {
          titulo: 'Como abordar qualquer peça nova',
          conteudo: [
            '1. Qual a função? (estrutural, estética, encaixe, calor?)',
            '2. Qual a força dominante e sua direção? → define orientação.',
            '3. Qual material atende função/ambiente? → define temperatura/cooling.',
            '4. Acabamento importa? → define camada e velocidade da parede externa.',
            '5. Qual o orçamento de tempo/custo? → define infill, paredes, suporte.',
            '6. Vai produzir em escala? → padronize um perfil comercial.',
          ],
        },
      ],
      estrutura: {
        oQueFaz:
          'Integra todo o curso num método de decisão repetível.',
        comoFunciona:
          'Função → forças → material → acabamento → custo → escala. Cada etapa restringe a próxima.',
        casosReais: [
          'Um cliente pede 200 suportes resistentes e baratos: PETG, bico 0,6, 4 paredes, 15% gyroid, 0,28 mm, tree support mínimo, agrupados por placa — decisão derivada do método.',
        ],
      },
      tabelas: [
        {
          titulo: 'Tabela-mestra de diagnóstico rápido',
          colunas: ['Sintoma', 'Causa provável', 'Correção'],
          linhas: [
            ['Ghosting', 'Aceleração sem IS', 'Calibrar Input Shaper'],
            ['Bolhas em cantos', 'PA descalibrado', 'Calibrar Pressure Advance'],
            ['Pillowing', 'Top layers/fan/infill', 'Mais top layers / ajustar fan'],
            ['Delaminação', 'Orientação/temperatura', 'Reorientar / + temperatura'],
            ['Stringing', 'Retração/temperatura', 'Calibrar retração / secar'],
            ['Warping', 'Adesão/cooling/câmara', 'Brim/raft, câmara, - fan'],
            ['Subextrusão', 'Fluxo/entupimento', 'Calibrar flow / limpar bico'],
          ],
        },
      ],
      exercicios: [
        'Para cada sintoma da tabela-mestra, escreva a sequência exata de ações que você tomaria.',
        'Receba 3 fotos de defeitos (reais) e diagnostique cada um com a causa e a correção.',
      ],
      testes: [
        'Qual a ordem correta de perguntas ao configurar uma peça nova?',
        'Diferencie ghosting de subextrusão pela aparência.',
        'Uma peça delamina sob tração: liste duas causas e como confirmar cada uma.',
      ],
      desafio:
        'EXAME FINAL: Você recebe um pedido comercial de 300 peças funcionais que sofrem flexão repetida, devem durar ao sol e ter bom acabamento, com prazo apertado e margem alvo de 3x. Defina material, orientação, todos os parâmetros de processo relevantes, plano de calibração, estratégia de produção em placas e a precificação. Justifique cada decisão tecnicamente. Esta é a prova do especialista absoluto.',
      perguntas: [
        {
          pergunta:
            'Como decidir entre mais paredes ou mais infill quando preciso de resistência com prazo curto?',
          resposta:
            'Priorize paredes: elas dão mais resistência por grama e por minuto que o infill. Aumente loops (4–5), mantenha infill 15–20% gyroid e oriente a carga ao longo das camadas. Infill alto só aumentaria tempo e peso sem ganho proporcional.',
        },
        {
          pergunta:
            'A peça precisa ser forte E barata E rápida. Os três ao mesmo tempo são possíveis?',
          resposta:
            'Raramente os três no máximo. O especialista escolhe o ponto de equilíbrio: orientação ótima (grátis) + paredes adequadas + gyroid 15% + bico maior + tree support. Isso entrega resistência alta, custo controlado e tempo razoável — sacrificando apenas detalhe fino.',
        },
      ],
    },
  ],
}
