import Link from 'next/link'
import Image from 'next/image'
import {
  ArrowRight,
  CircleDot,
  Gauge,
  GraduationCap,
  Layers,
  Wrench,
} from 'lucide-react'
import { modulos, totalLicoes } from '@/lib/course'
import { ModuleGrid, HomeProgressBanner } from '@/components/module-grid'

const destaques = [
  {
    icon: Layers,
    titulo: `${modulos.length} Módulos Progressivos`,
    texto: 'Do primeiro slice à produção comercial, em ordem lógica.',
  },
  {
    icon: Gauge,
    titulo: 'Calibração Científica',
    texto: 'Flow, PA, temperatura, retração e velocidade na prática.',
  },
  {
    icon: Wrench,
    titulo: 'Engenharia Mecânica',
    texto: 'Peças funcionais resistentes, encaixes e tolerâncias.',
  },
  {
    icon: GraduationCap,
    titulo: 'Nível Especialista',
    texto: 'Perfis customizados, G-code e fluxo de produção.',
  },
]

export default function Page() {
  const primeira = modulos[0].licoes[0]
  const inicioHref = `/licao/${modulos[0].slug}/${primeira.slug}`

  return (
    <main className="min-h-screen bg-background">
      {/* HERO */}
      <section className="relative overflow-hidden border-b border-border">
        <div className="absolute inset-0">
          <Image
            src="/hero-printer.png"
            alt="Impressora 3D FDM imprimindo uma peça laranja"
            fill
            priority
            className="object-cover opacity-25"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-background via-background/85 to-background/60" />
        </div>

        <div className="relative mx-auto max-w-6xl px-6 py-20 md:py-28">
          <div className="flex items-center gap-2.5">
            <div className="flex h-9 w-9 items-center justify-center rounded-md bg-primary text-primary-foreground">
              <CircleDot className="h-5 w-5" />
            </div>
            <span className="font-mono text-sm font-bold tracking-tight text-foreground">
              MESTRE ORCA
            </span>
          </div>

          <h1 className="mt-8 max-w-3xl text-balance text-4xl font-bold leading-[1.05] tracking-tight text-foreground md:text-6xl">
            Torne-se um{' '}
            <span className="text-primary">especialista absoluto</span> em
            OrcaSlicer
          </h1>
          <p className="mt-5 max-w-2xl text-pretty text-lg leading-relaxed text-muted-foreground">
            O curso completo de impressão 3D FDM através do OrcaSlicer. Domine
            cada parâmetro, calibre como um engenheiro e produza peças
            profissionais — do zero ao nível mestre.
          </p>

          <div className="mt-8 flex flex-wrap items-center gap-3">
            <Link
              href={inicioHref}
              className="inline-flex items-center gap-2 rounded-lg bg-primary px-6 py-3 font-medium text-primary-foreground transition-colors hover:bg-primary/90"
            >
              Começar agora
              <ArrowRight className="h-4 w-4" />
            </Link>
            <a
              href="#modulos"
              className="inline-flex items-center gap-2 rounded-lg border border-border bg-card px-6 py-3 font-medium text-foreground transition-colors hover:bg-muted"
            >
              Ver currículo
            </a>
          </div>

          <div className="mt-10 flex flex-wrap gap-x-8 gap-y-3 font-mono text-sm">
            <div>
              <span className="text-2xl font-bold text-primary">
                {modulos.length}
              </span>
              <span className="ml-2 text-muted-foreground">módulos</span>
            </div>
            <div>
              <span className="text-2xl font-bold text-primary">
                {totalLicoes}
              </span>
              <span className="ml-2 text-muted-foreground">lições</span>
            </div>
            <div>
              <span className="text-2xl font-bold text-primary">4</span>
              <span className="ml-2 text-muted-foreground">níveis</span>
            </div>
          </div>
        </div>
      </section>

      {/* DESTAQUES */}
      <section className="mx-auto max-w-6xl px-6 py-12">
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {destaques.map((d) => (
            <div
              key={d.titulo}
              className="rounded-xl border border-border bg-card p-5"
            >
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10 text-primary">
                <d.icon className="h-5 w-5" />
              </div>
              <h3 className="mt-3 font-semibold text-foreground">{d.titulo}</h3>
              <p className="mt-1 text-sm leading-relaxed text-muted-foreground">
                {d.texto}
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* MÓDULOS */}
      <section id="modulos" className="mx-auto max-w-6xl px-6 pb-20">
        <div className="mb-6">
          <p className="font-mono text-sm font-medium text-primary">
            CURRÍCULO COMPLETO
          </p>
          <h2 className="mt-1 text-balance text-3xl font-bold tracking-tight text-foreground">
            Sua trilha rumo à maestria
          </h2>
          <p className="mt-2 max-w-2xl text-muted-foreground">
            Cada módulo se aprofunda em um pilar do OrcaSlicer. Conclua na ordem
            para construir uma base sólida e progressiva.
          </p>
        </div>

        <HomeProgressBanner />
        <ModuleGrid />
      </section>

      <footer className="border-t border-border">
        <div className="mx-auto max-w-6xl px-6 py-8">
          <p className="text-sm text-muted-foreground">
            Mestre Orca — Curso de Impressão 3D FDM com OrcaSlicer. Conteúdo
            educacional para makers, engenheiros e profissionais.
          </p>
        </div>
      </footer>
    </main>
  )
}
