import type { Metadata } from 'next'
import { modulos, getImagemArquivo, getImagemPrompt } from '@/lib/course'
import { ImagensAdminView } from '@/components/imagens-admin-view'

export const metadata: Metadata = {
  title: 'Prompts de imagens (privado)',
  robots: { index: false, follow: false },
}

export default function AdminImagensPage() {
  const itens = modulos.flatMap((m) =>
    m.licoes.map((l) => ({
      moduloNumero: m.numero,
      moduloTitulo: m.titulo,
      moduloSlug: m.slug,
      licaoTitulo: l.titulo,
      arquivo: getImagemArquivo(m.slug, l.slug),
      prompt: getImagemPrompt(m, l),
    })),
  )

  return <ImagensAdminView itens={itens} />
}
