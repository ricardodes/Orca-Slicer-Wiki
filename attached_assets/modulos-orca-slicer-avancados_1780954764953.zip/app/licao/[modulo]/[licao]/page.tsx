import { notFound } from 'next/navigation'
import type { Metadata } from 'next'
import { CourseShell } from '@/components/course-shell'
import { LessonView } from '@/components/lesson-view'
import {
  getLicao,
  getAdjacentLicoes,
  getFlatLicoes,
} from '@/lib/course'

export function generateStaticParams() {
  return getFlatLicoes().map((f) => ({
    modulo: f.moduloSlug,
    licao: f.licao.slug,
  }))
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ modulo: string; licao: string }>
}): Promise<Metadata> {
  const { modulo, licao } = await params
  const found = getLicao(modulo, licao)
  if (!found) return { title: 'Lição não encontrada' }
  return {
    title: `${found.licao.titulo} — Mestre Orca`,
    description: found.licao.resumo,
  }
}

export default async function LicaoPage({
  params,
}: {
  params: Promise<{ modulo: string; licao: string }>
}) {
  const { modulo, licao } = await params
  const found = getLicao(modulo, licao)
  if (!found) notFound()

  const nav = getAdjacentLicoes(modulo, licao)

  return (
    <CourseShell>
      <LessonView
        moduloSlug={modulo}
        moduloNumero={found.modulo.numero}
        moduloTitulo={found.modulo.titulo}
        licao={found.licao}
        nav={nav}
      />
    </CourseShell>
  )
}
