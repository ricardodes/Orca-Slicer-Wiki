'use client'

import { useCallback, useEffect, useState } from 'react'

const STORAGE_KEY = 'orca-curso-progresso-v1'

type ProgressoState = Record<string, boolean>

function ler(): ProgressoState {
  if (typeof window === 'undefined') return {}
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY)
    return raw ? (JSON.parse(raw) as ProgressoState) : {}
  } catch {
    return {}
  }
}

export function useProgresso() {
  const [concluidas, setConcluidas] = useState<ProgressoState>({})
  const [carregado, setCarregado] = useState(false)

  useEffect(() => {
    setConcluidas(ler())
    setCarregado(true)
  }, [])

  // Sincroniza entre abas/componentes
  useEffect(() => {
    function onStorage(e: StorageEvent) {
      if (e.key === STORAGE_KEY) setConcluidas(ler())
    }
    function onCustom() {
      setConcluidas(ler())
    }
    window.addEventListener('storage', onStorage)
    window.addEventListener('orca-progresso-updated', onCustom)
    return () => {
      window.removeEventListener('storage', onStorage)
      window.removeEventListener('orca-progresso-updated', onCustom)
    }
  }, [])

  const persistir = useCallback((next: ProgressoState) => {
    setConcluidas(next)
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(next))
      window.dispatchEvent(new Event('orca-progresso-updated'))
    } catch {
      // ignore
    }
  }, [])

  const alternar = useCallback(
    (id: string) => {
      const next = { ...ler() }
      if (next[id]) {
        delete next[id]
      } else {
        next[id] = true
      }
      persistir(next)
    },
    [persistir],
  )

  const marcar = useCallback(
    (id: string, valor: boolean) => {
      const next = { ...ler() }
      if (valor) next[id] = true
      else delete next[id]
      persistir(next)
    },
    [persistir],
  )

  const estaConcluida = useCallback(
    (id: string) => Boolean(concluidas[id]),
    [concluidas],
  )

  const resetar = useCallback(() => {
    persistir({})
  }, [persistir])

  const totalConcluidas = Object.keys(concluidas).length

  return {
    concluidas,
    carregado,
    alternar,
    marcar,
    estaConcluida,
    resetar,
    totalConcluidas,
  }
}
